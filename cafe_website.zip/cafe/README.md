# ☕ Café Delight - Dynamic Website

A full-fledged dynamic website for a fictitious local café business, demonstrating advanced web technologies including XML, JSON, AJAX, DOM manipulation, and PHP.

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Technologies Used](#technologies-used)
- [Installation](#installation)
- [Usage](#usage)
- [Project Structure](#project-structure)
- [Requirements Demonstration](#requirements-demonstration)
- [Admin Panel](#admin-panel)
- [API Endpoints](#api-endpoints)
- [Database](#database)

---

## 🎯 Overview

Café Delight is a complete dynamic website showcasing modern web development techniques. The website includes a public-facing site with menu, about, contact, and reservation pages, plus a comprehensive admin panel for content management.

**Portfolio note:** Large image assets have been resized and compressed for a more practical repository size. Image filenames and references are preserved.

**Security note:** This is a local coursework/demo project. The current sample authentication and XAMPP database setup are not production-ready. Do not deploy the admin panel publicly without replacing the demo credentials, removing fallback authentication, and configuring secure database credentials.

**Key Highlights:**
- Dynamic content loading using AJAX
- Complex XML and JSON data structures
- Database integration with JSON fallback
- Responsive design with modern UI
- Admin panel for content management

---

## ✨ Features

### Public Website

- **Home Page** - Hero section, story section, special offers loaded dynamically
- **Menu Page** - Dynamic menu loading from database/XML with category filtering
- **About Page** - Staff information displayed dynamically
- **Contact Page** - Contact form with AJAX submission, contact information display
- **Reservation Page** - Table reservation system with form validation

### Admin Panel

- **Dashboard** - Statistics and overview
- **Menu Management** - Add/edit/delete menu items (XML and SQL)
- **Data Management** - Manage offers, features, contact information
- **Reservation Management** - View and manage customer reservations
- **Contact Messages** - View submitted contact form messages

### Technical Features

- Multi-level fallback system (SQL → JSON → XML)
- Real-time form validation
- Dynamic DOM manipulation
- Responsive design
- Error handling and graceful degradation

---

## 🛠 Technologies Used

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Modern styling with animations
- **JavaScript** - DOM manipulation, AJAX, form validation
- **Fetch API / XMLHttpRequest** - Asynchronous data loading

### Backend
- **PHP** - Server-side processing, API endpoints
- **MySQL** - Database storage
- **XML** - Menu data structure
- **JSON** - Data storage and API responses

### Libraries & Tools
- **DOMDocument** - XML manipulation in PHP
- **PDO** - Database abstraction layer
- **XAMPP** - Development environment

---

## 📦 Installation

### Prerequisites

- XAMPP (or similar PHP/MySQL environment)
- Apache server
- MySQL database
- PHP 7.4 or higher

### Setup Steps

1. **Clone/Download the project**
   ```bash
   # Place the 'cafe' folder in your XAMPP htdocs directory
   # Path: C:\xampp\htdocs\cafe (Windows)
   # Path: /Applications/XAMPP/xamppfiles/htdocs/cafe (Mac)
   ```

2. **Start XAMPP Services**
   - Start Apache
   - Start MySQL

3. **Install Database**
   - Open your browser and navigate to:
     ```
     http://localhost/cafe/database/install.php
     ```
   - Click "Install Database" button
   - Wait for confirmation message

4. **Access the Website**
   - Homepage: `http://localhost/cafe/index.php`
   - Admin Panel: `http://localhost/cafe/admin/login.php`

---

## 🚀 Usage

### Public Website

1. **Homepage** (`index.php`)
   - View café information and special offers
   - Subscribe to newsletter

2. **Menu** (`menu.php`)
   - Browse menu items by category
   - Filter by: All, Beverages, Food, Desserts

3. **About** (`about.php`)
   - Learn about the café
   - View staff information

4. **Contact** (`contact.php`)
   - View contact information and hours
   - Submit contact form

5. **Reservation** (`reservation.php`)
   - Book a table reservation
   - Form validation included

### Admin Panel

**Admin login:** The local demo installer seeds a demonstration administrator account. Do not use the demo account or fallback login on a deployed website. Change the credentials and remove demo authentication before deployment.

**Admin Features:**
- Dashboard with statistics
- Manage menu items (add/delete)
- Manage offers and features
- View and manage reservations
- View contact messages

---

## 📁 Project Structure

```
cafe/
├── index.php                 # Homepage
├── menu.php                  # Menu page
├── about.php                 # About page
├── contact.php               # Contact page
├── reservation.php           # Reservation page
│
├── admin/                    # Admin panel
│   ├── login.php
│   ├── dashboard.php
│   ├── manage_menu.php      # XML menu management
│   ├── manage_sql.php       # SQL menu management
│   ├── manage_data.php      # Data management
│   ├── manage_reservations.php
│   └── manage_contact.php
│
├── api/                      # API endpoints
│   ├── get_menu.php         # XML menu API
│   ├── get_menu_sql.php     # SQL menu API
│   ├── get_staff.php        # Staff JSON API
│   ├── get_offers.php       # Offers JSON API
│   ├── get_contact.php      # Contact info API
│   ├── submit_contact.php   # Contact form handler
│   └── submit_reservation.php # Reservation handler
│
├── css/                      # Stylesheets
│   ├── style.css            # Main styles
│   ├── menu-cards.css       # Menu-specific styles
│   └── admin.css            # Admin panel styles
│
├── js/                       # JavaScript files
│   ├── main.js              # Homepage functionality
│   ├── menu.js              # Menu page (XML/AJAX)
│   ├── about.js             # About page
│   ├── contact.js           # Contact page
│   └── reservation.js       # Reservation page
│
├── data/                     # Data files
│   ├── menu.xml             # Menu XML file
│   └── data.json            # JSON data file
│
├── config/                   # Configuration
│   └── database.php         # Database connection
│
├── database/                 # Database files
│   ├── install.php          # Database installer
│   └── schema.sql           # Database schema
│
└── image/                    # Images
    └── [various image files]
```

---

## 📚 Requirements Demonstration

This project demonstrates all coursework requirements:

### Core Requirements

✅ **Home Page** - `index.php`  
✅ **Navigation Menus** - All pages include consistent navigation  
✅ **XML with AJAX** - `menu.php` + `js/menu.js` + `api/get_menu.php`  
✅ **JSON with AJAX** - Multiple pages use JSON via AJAX  
✅ **DOM Manipulation** - All JavaScript files demonstrate DOM methods  
✅ **PHP** - Server-side processing throughout  

### Advanced Requirements

✅ **Complex XML** - `data/menu.xml` (multiple child elements, attributes)  
✅ **JSON with Arrays & Nested Objects** - `data/data.json`  
✅ **PHP Manipulates XML** - `admin/manage_menu.php`, `api/get_menu.php`  
✅ **PHP Manipulates JSON** - `api/submit_contact.php`, `api/submit_reservation.php`  

### Bonus Features

✅ Database integration with JSON fallback  
✅ Auto-table creation  
✅ Multi-level fallback system  
✅ Comprehensive error handling  
✅ Modern UI/UX design  

---

## 🔐 Admin Panel

### Access
- URL: `http://localhost/cafe/admin/login.php`
- Demo administrator account is for local coursework testing only. Change it before deployment.

### Features

**Dashboard**
- View statistics (menu items, staff, offers, ratings)
- Quick navigation to management pages

**Manage Menu (XML)**
- Add menu items to XML file
- Delete menu items
- View current XML structure

**Manage Menu (SQL)**
- Add menu items to database
- Delete menu items
- Manage categories and features

**Manage Data**
- Update contact information
- Add/edit special offers
- Manage features

**Reservations**
- View all reservations
- Filter by status (pending, confirmed, cancelled)
- Update reservation status
- Delete reservations

**Contact Messages**
- View submitted contact forms
- Mark messages as read

---

## 🔌 API Endpoints

All APIs support database operations with JSON fallback:

| Endpoint | Method | Description | Returns |
|----------|--------|-------------|---------|
| `api/get_menu.php` | GET | Get menu from XML | XML |
| `api/get_menu_sql.php` | GET | Get menu from database | JSON |
| `api/get_staff.php` | GET | Get staff information | JSON |
| `api/get_staff_sql.php` | GET | Get staff from database | JSON |
| `api/get_offers.php` | GET | Get special offers | JSON |
| `api/get_offers_sql.php` | GET | Get offers from database | JSON |
| `api/get_contact.php` | GET | Get contact information | JSON |
| `api/submit_contact.php` | POST | Submit contact form | JSON |
| `api/submit_reservation.php` | POST | Submit reservation | JSON |

---

## 💾 Database

### Tables

- `admin_users` - Admin accounts
- `menu_items` - Menu items
- `categories` - Menu categories
- `ingredients` - Menu ingredients
- `features` - Website features
- `offers` - Special offers
- `staff` - Staff members
- `staff_specialties` - Staff specialties
- `reviews` - Customer reviews
- `contact_messages` - Contact form submissions
- `cafe_settings` - Website settings
- `reservations` - Table reservations (auto-created)

### Installation

The database is automatically installed via:
```
http://localhost/cafe/database/install.php
```

Or manually using:
```sql
-- Run the schema.sql file in phpMyAdmin
-- Or import via: database/schema.sql
```

---

## 🎨 Design Features

- **Modern UI** - Clean, professional design
- **Responsive** - Works on desktop, tablet, and mobile
- **Animations** - Smooth transitions and hover effects
- **Color Scheme** - Mocha Noir theme (browns and golds)
- **Accessibility** - Semantic HTML and proper labels

---

## 🐛 Troubleshooting

### Menu items not showing
- Check if database is installed
- Verify `menu_items` table has data
- Check browser console for errors
- Try refreshing the page

### Database connection errors
- Ensure MySQL is running in XAMPP
- Check `config/database.php` settings
- Verify database exists: `cafe_db`

### Admin login not working
- The project includes demo-only administrator authentication. Replace it before deployment.
- Check `admin_users` table exists
- Clear browser cache if needed

### Images not loading
- Verify `image/` folder exists
- Check file paths in menu items
- Ensure image files are uploaded

---

## 📝 Notes

- The website uses a multi-level fallback system:
  1. Tries SQL database first
  2. Falls back to JSON if database unavailable
  3. Falls back to XML if JSON unavailable
  4. Falls back to static files as last resort

- All form submissions are validated both client-side and server-side

- The reservation table is auto-created if it doesn't exist

- All code includes comments explaining functionality

---

## 👨‍💻 Development

### Adding New Menu Items

**Via Admin Panel:**
1. Login to admin panel
2. Go to "Manage Menu"
3. Fill in form and submit

**Via Database:**
- Insert directly into `menu_items` table
- Or use `admin/manage_sql.php`

### Modifying Data

- Edit `data/data.json` for JSON data
- Edit `data/menu.xml` for XML data
- Or use admin panel for easier management

---

## 📄 License

This project is created for educational purposes as part of the Internet Technologies and Web Services coursework.

---

## 🙏 Acknowledgments

- Built with XAMPP development environment
- Uses modern web standards (HTML5, CSS3, ES6+)
- Follows best practices for security and performance

---

**Last Updated:** 2024  
**Version:** 1.0  
**Status:** Production Ready ✅

