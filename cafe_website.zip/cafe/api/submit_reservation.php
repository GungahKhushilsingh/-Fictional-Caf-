<?php
/**
 * submit_reservation.php - Handle reservation form submission
 * Saves reservations to database - SIMPLIFIED AND FIXED VERSION
 */

header('Content-Type: application/json; charset=utf-8');

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Get and validate form data
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
$date = isset($_POST['date']) ? trim($_POST['date']) : '';
$time = isset($_POST['time']) ? trim($_POST['time']) : '';
$guests = isset($_POST['guests']) ? intval($_POST['guests']) : 0;

// Validate all required fields
if (empty($name) || empty($email) || empty($phone) || empty($date) || empty($time) || $guests < 1) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'All fields are required']);
    exit;
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid email format']);
    exit;
}

// Validate date (not in past)
$reservationDate = new DateTime($date);
$today = new DateTime();
$today->setTime(0, 0, 0);
if ($reservationDate < $today) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Reservation date cannot be in the past']);
    exit;
}

// Validate guests count
if ($guests < 1 || $guests > 16) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Number of guests must be between 1 and 16']);
    exit;
}

// Try to save to database
try {
    require_once '../config/database.php';
    $pdo = getDBConnection();
    
    // Ensure reservations table exists
    $createTableSql = "CREATE TABLE IF NOT EXISTS reservations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        reservation_date DATE NOT NULL,
        reservation_time TIME NOT NULL,
        guests INT NOT NULL,
        status VARCHAR(20) DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_date (reservation_date),
        INDEX idx_status (status),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    $pdo->exec($createTableSql);
    
    // Insert reservation - use direct values without htmlspecialchars for database
    $sql = "INSERT INTO reservations (name, email, phone, reservation_date, reservation_time, guests, status) 
            VALUES (:name, :email, :phone, :date, :time, :guests, 'pending')";
    
    $stmt = $pdo->prepare($sql);
    $result = $stmt->execute([
        ':name' => $name,
        ':email' => $email,
        ':phone' => $phone,
        ':date' => $date,
        ':time' => $time,
        ':guests' => $guests
    ]);
    
    if (!$result) {
        throw new Exception('Failed to execute INSERT statement');
    }
    
    // Get the inserted ID
    $reservationId = $pdo->lastInsertId();
    
    if (!$reservationId) {
        // Try to find the reservation we just inserted
        $checkSql = "SELECT id FROM reservations WHERE email = :email AND reservation_date = :date AND reservation_time = :time ORDER BY id DESC LIMIT 1";
        $checkStmt = $pdo->prepare($checkSql);
        $checkStmt->execute([
            ':email' => $email,
            ':date' => $date,
            ':time' => $time
        ]);
        $found = $checkStmt->fetch();
        if ($found) {
            $reservationId = $found['id'];
        } else {
            throw new Exception('Reservation was not saved - could not retrieve ID');
        }
    }
    
    // Success response
    echo json_encode([
        'success' => true,
        'message' => 'Reservation received! We will confirm shortly. Your reservation ID is: ' . $reservationId,
        'reservation_id' => $reservationId
    ]);
    
    exit;
    
} catch (PDOException $e) {
    // Database error - return error but also try JSON fallback
    $errorMessage = $e->getMessage();
    
    // Try JSON fallback
    try {
        $jsonFile = dirname(__DIR__) . '/data/reservations.json';
        $reservations = [];
        
        if (file_exists($jsonFile)) {
            $jsonData = file_get_contents($jsonFile);
            $reservations = json_decode($jsonData, true);
            if (!is_array($reservations)) {
                $reservations = [];
            }
        }
        
        $newReservation = [
            'id' => count($reservations) + 1,
            'name' => htmlspecialchars($name),
            'email' => htmlspecialchars($email),
            'phone' => htmlspecialchars($phone),
            'date' => $date,
            'time' => $time,
            'guests' => $guests,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $reservations[] = $newReservation;
        
        // Ensure directory exists
        $dir = dirname($jsonFile);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        
        file_put_contents($jsonFile, json_encode($reservations, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        
        echo json_encode([
            'success' => true,
            'message' => 'Reservation received! (Saved to backup file - database unavailable)',
            'reservation_id' => $newReservation['id'],
            'warning' => 'Database error: ' . $errorMessage
        ]);
        exit;
        
    } catch (Exception $jsonError) {
        // Both failed
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Failed to save reservation. Please contact us directly.',
            'debug' => $errorMessage
        ]);
        exit;
    }
    
} catch (Exception $e) {
    // Generic error
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'An error occurred. Please try again.',
        'debug' => $e->getMessage()
    ]);
    exit;
}
?>
