<?php
/**
 * get_staff_sql.php - Get staff from SQL database with JSON fallback
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');

try {
    require_once '../config/database.php';
    $pdo = getDBConnection();
    
    $sql = "SELECT s.id, s.name, s.position, s.bio, s.years_of_service as yearsOfService
            FROM staff s
            WHERE s.is_active = 1
            ORDER BY s.years_of_service DESC";
    
    $staff = fetchAll($sql);
    
    // Get specialties for each staff member
    foreach ($staff as &$member) {
        $specialtySql = "SELECT specialty FROM staff_specialties WHERE staff_id = ?";
        $specialties = fetchAll($specialtySql, [$member['id']]);
        $member['specialties'] = array_column($specialties, 'specialty');
    }
    
    echo json_encode($staff, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    // Fallback to JSON
    $jsonFile = '../data/data.json';
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $data = json_decode($jsonData, true);
        if ($data && isset($data['staff'])) {
            echo json_encode($data['staff'], JSON_PRETTY_PRINT);
            exit;
        }
    }
    
    http_response_code(500);
    echo json_encode([
        'error' => 'Failed to load staff information',
        'message' => $e->getMessage()
    ]);
}
?>

