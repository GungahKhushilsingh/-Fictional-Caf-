<?php
/**
 * PHP file to get offers from JSON data
 * Returns only the offers array
 */

header('Content-Type: application/json; charset=utf-8');

$jsonFile = '../data/data.json';

if (!file_exists($jsonFile)) {
    http_response_code(404);
    echo json_encode(['error' => 'Data file not found']);
    exit;
}

$jsonData = file_get_contents($jsonFile);
$data = json_decode($jsonData, true);

if ($data === null || !isset($data['offers'])) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to load offers']);
    exit;
}

echo json_encode($data['offers'], JSON_PRETTY_PRINT);
?>

