<?php
/**
 * debug_menu.php - Debug tool to check menu items
 * Use this to see what's in the database vs what the API returns
 */

require_once '../config/database.php';

header('Content-Type: text/html; charset=utf-8');

?>
<!DOCTYPE html>
<html>
<head>
    <title>Menu Debug Tool</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        table { border-collapse: collapse; width: 100%; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #6f4e37; color: white; }
        .error { color: red; }
        .success { color: green; }
    </style>
</head>
<body>
    <h1>Menu Debug Tool</h1>
    
    <?php
    try {
        $pdo = getDBConnection();
        
        // 1. Check all menu items in database
        echo "<h2>1. All Menu Items in Database</h2>";
        $allItems = fetchAll("SELECT * FROM menu_items ORDER BY id DESC LIMIT 10");
        if ($allItems) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Name</th><th>Category ID</th><th>is_available</th><th>Price</th></tr>";
            foreach ($allItems as $item) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($item['id']) . "</td>";
                echo "<td>" . htmlspecialchars($item['name']) . "</td>";
                echo "<td>" . htmlspecialchars($item['category_id'] ?? 'NULL') . "</td>";
                echo "<td>" . ($item['is_available'] ? '✓ YES' : '✗ NO') . "</td>";
                echo "<td>$" . htmlspecialchars($item['price']) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='error'>No items found in database!</p>";
        }
        
        // 2. Check categories
        echo "<h2>2. Categories Status</h2>";
        $categories = fetchAll("SELECT id, name, slug, is_available FROM categories");
        if ($categories) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Name</th><th>Slug</th><th>is_available</th></tr>";
            foreach ($categories as $cat) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($cat['id']) . "</td>";
                echo "<td>" . htmlspecialchars($cat['name']) . "</td>";
                echo "<td>" . htmlspecialchars($cat['slug']) . "</td>";
                echo "<td>" . ($cat['is_available'] ? '✓ YES' : '✗ NO') . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
        // 3. Check what the API query would return
        echo "<h2>3. Items That Pass API Filter (is_available=1 AND category available)</h2>";
        $apiItems = fetchAll("
            SELECT 
                m.id, m.name, m.description, m.price, 
                m.is_available as item_available,
                c.id as category_id, c.name as category_name, 
                c.slug as category_slug, c.is_available as category_available
            FROM menu_items m
            LEFT JOIN categories c ON m.category_id = c.id
            WHERE m.is_available = 1 AND (c.is_available = 1 OR c.id IS NULL)
            ORDER BY m.id DESC
        ");
        if ($apiItems) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Name</th><th>Category</th><th>Category Slug</th><th>Price</th></tr>";
            foreach ($apiItems as $item) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($item['id']) . "</td>";
                echo "<td>" . htmlspecialchars($item['name']) . "</td>";
                echo "<td>" . htmlspecialchars($item['category_name'] ?? 'NULL') . "</td>";
                echo "<td>" . htmlspecialchars($item['category_slug'] ?? 'NULL') . "</td>";
                echo "<td>$" . htmlspecialchars($item['price']) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='error'>No items pass the API filter!</p>";
        }
        
        // 4. Check items that DON'T pass filter
        echo "<h2>4. Items That DON'T Pass Filter (Hidden Items)</h2>";
        $hiddenItems = fetchAll("
            SELECT 
                m.id, m.name, 
                m.is_available as item_available,
                c.id as category_id, c.name as category_name,
                c.is_available as category_available
            FROM menu_items m
            LEFT JOIN categories c ON m.category_id = c.id
            WHERE m.is_available = 0 OR c.is_available = 0 OR (c.id IS NULL AND m.category_id IS NOT NULL)
            ORDER BY m.id DESC
        ");
        if ($hiddenItems) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Name</th><th>Item Available</th><th>Category</th><th>Category Available</th><th>Issue</th></tr>";
            foreach ($hiddenItems as $item) {
                $issue = [];
                if (!$item['item_available']) $issue[] = 'Item marked unavailable';
                if ($item['category_id'] && !$item['category_available']) $issue[] = 'Category unavailable';
                if (!$item['category_id'] && $item['category_id'] !== null) $issue[] = 'Invalid category_id';
                
                echo "<tr>";
                echo "<td>" . htmlspecialchars($item['id']) . "</td>";
                echo "<td>" . htmlspecialchars($item['name']) . "</td>";
                echo "<td>" . ($item['item_available'] ? '✓' : '✗') . "</td>";
                echo "<td>" . htmlspecialchars($item['category_name'] ?? 'NULL') . "</td>";
                echo "<td>" . ($item['category_available'] ? '✓' : '✗') . "</td>";
                echo "<td>" . implode(', ', $issue) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='success'>All items pass the filter!</p>";
        }
        
        // 5. Test API endpoint directly
        echo "<h2>5. Test API Response</h2>";
        echo "<p><a href='get_menu_sql.php' target='_blank'>Open API in new tab</a></p>";
        
    } catch (Exception $e) {
        echo "<p class='error'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
    ?>
    
    <hr>
    <p><a href="../menu.php">Back to Menu Page</a> | <a href="../admin/manage_sql.php">Admin Panel</a></p>
</body>
</html>

