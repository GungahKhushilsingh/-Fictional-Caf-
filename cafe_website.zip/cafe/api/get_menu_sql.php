<?php
/**
 * get_menu_sql.php - Get menu items from SQL database
 * Alternative API endpoint that uses database instead of XML
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

require_once '../config/database.php';

try {
    $pdo = getDBConnection();
    
    // Get menu items with categories and ingredients
    $sql = "SELECT 
                m.id, m.name, m.description, m.price, m.currency, 
                m.size, m.size_unit, m.calories, m.contains_caffeine as caffeine,
                m.is_popular as popular, m.image,
                c.id as category_id, c.name as category_name, c.type as category_type,
                c.slug as category_slug
            FROM menu_items m
            LEFT JOIN categories c ON m.category_id = c.id
            WHERE m.is_available = 1 AND (c.is_available = 1 OR c.id IS NULL)
            ORDER BY c.display_order, m.name";
    
    $items = fetchAll($sql);
    
    // Get ingredients for each item
    foreach ($items as &$item) {
        $ingredientSql = "SELECT name FROM ingredients WHERE menu_item_id = ?";
        $ingredients = fetchAll($ingredientSql, [$item['id']]);
        $item['ingredients'] = array_column($ingredients, 'name');
    }
    
    // Group by category
    $menu = [];
    foreach ($items as $item) {
        // Use category slug, or fallback to category name lowercase, or 'uncategorized'
        if (!empty($item['category_slug'])) {
            $categoryId = $item['category_slug'];
        } elseif (!empty($item['category_name'])) {
            $categoryId = strtolower(str_replace(' ', '_', $item['category_name']));
        } else {
            $categoryId = 'uncategorized';
        }
        
        // Ensure category ID is valid
        if (empty($categoryId)) {
            $categoryId = 'uncategorized';
        }
        
        if (!isset($menu[$categoryId])) {
            $menu[$categoryId] = [
                'id' => $categoryId,
                'type' => $item['category_type'] ?? 
                         (isset($item['category_name']) ? strtolower($item['category_name']) : 'other'),
                'available' => true,
                'items' => []
            ];
        }
        
        $menuItem = [
            'id' => (string)$item['id'],
            'price' => (string)$item['price'],
            'currency' => $item['currency'],
            'popular' => (bool)$item['popular'],
            'name' => $item['name'],
            'description' => $item['description'],
            'size' => [
                'unit' => $item['size_unit'],
                'value' => $item['size']
            ],
            'ingredients' => array_map(function($ing) {
                return ['ingredient' => $ing];
            }, $item['ingredients']),
            'nutrition' => [
                'calories' => (string)$item['calories'],
                'caffeine' => (bool)$item['caffeine']
            ]
        ];
        
        // Add image if available (check for both null and empty string)
        if (!empty($item['image']) && trim($item['image']) !== '') {
            $menuItem['image'] = trim($item['image']);
        }
        
        $menu[$categoryId]['items'][] = $menuItem;
    }
    
    // Convert to array format similar to XML structure
    $result = [
        'menu' => array_values($menu),
        'lastUpdated' => date('Y-m-d H:i:s'),
        'totalItems' => count($items)
    ];
    
    echo json_encode($result, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Database error',
        'message' => $e->getMessage()
    ]);
}
?>

