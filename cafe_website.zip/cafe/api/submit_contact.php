<?php
/**
 * PHP file to handle contact form submission
 * Demonstrates JSON manipulation by adding new data
 */

header('Content-Type: application/json; charset=utf-8');

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get form data
$name = isset($_POST['name']) ? htmlspecialchars(trim($_POST['name'])) : '';
$email = isset($_POST['email']) ? htmlspecialchars(trim($_POST['email'])) : '';
$message = isset($_POST['message']) ? htmlspecialchars(trim($_POST['message'])) : '';

// Validate input
if (empty($name) || empty($email) || empty($message)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'All fields are required']);
    exit;
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid email format']);
    exit;
}

// Read existing JSON data
$jsonFile = '../data/data.json';
$jsonData = file_get_contents($jsonFile);
$data = json_decode($jsonData, true);

// Add new submission to messages (if messages array exists, otherwise create it)
if (!isset($data['messages'])) {
    $data['messages'] = [];
}

// Add new message
$newMessage = [
    'id' => count($data['messages']) + 1,
    'name' => $name,
    'email' => $email,
    'message' => $message,
    'date' => date('Y-m-d H:i:s'),
    'read' => false
];

$data['messages'][] = $newMessage;

// Try to save to database first, fallback to JSON
try {
    require_once '../config/database.php';
    $pdo = getDBConnection();
    
    // Insert into database
    $sql = "INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$name, $email, $message]);
    
    // Success - saved to database
} catch (Exception $e) {
    // Fallback to JSON if database not available
    file_put_contents($jsonFile, json_encode($data, JSON_PRETTY_PRINT));
}

// Return success response
echo json_encode([
    'success' => true,
    'message' => 'Thank you for your message! We will get back to you soon.'
]);
?>

