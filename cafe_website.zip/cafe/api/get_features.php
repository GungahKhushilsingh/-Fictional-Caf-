<?php
/**
 * PHP file to get features from JSON data
 * Returns only the features array
 */

header('Content-Type: application/json; charset=utf-8');

$jsonFile = '../data/data.json';

if (!file_exists($jsonFile)) {
    http_response_code(404);
    echo json_encode(['error' => 'Data file not found']);
    exit;
}

$jsonData = file_get_contents($jsonFile);
$data = json_decode($jsonData, true);

if ($data === null || !isset($data['features'])) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to load features']);
    exit;
}

echo json_encode($data['features'], JSON_PRETTY_PRINT);
?>

