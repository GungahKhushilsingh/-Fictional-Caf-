<?php
/**
 * PHP file to manipulate and serve JSON data
 * Demonstrates JSON manipulation using PHP
 * 
 * This script reads the data.json file, manipulates it,
 * and outputs it for AJAX requests
 */

header('Content-Type: application/json; charset=utf-8');

// Path to the JSON file
$jsonFile = '../data/data.json';

// Check if file exists
if (!file_exists($jsonFile)) {
    http_response_code(404);
    echo json_encode(['error' => 'Data file not found']);
    exit;
}

// Read and decode JSON file
$jsonData = file_get_contents($jsonFile);
$data = json_decode($jsonData, true);

if ($data === null) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to parse JSON file']);
    exit;
}

// Manipulate JSON: Add current timestamp
$data['lastUpdated'] = date('Y-m-d H:i:s');

// Manipulate JSON: Calculate average rating from reviews
if (isset($data['reviews']) && is_array($data['reviews']) && count($data['reviews']) > 0) {
    $totalRating = 0;
    foreach ($data['reviews'] as $review) {
        $totalRating += $review['rating'];
    }
    $data['averageRating'] = round($totalRating / count($data['reviews']), 2);
}

// Manipulate JSON: Add total number of staff
if (isset($data['staff']) && is_array($data['staff'])) {
    $data['totalStaff'] = count($data['staff']);
}

// Manipulate JSON: Count total offers
if (isset($data['offers']) && is_array($data['offers'])) {
    $data['totalOffers'] = count($data['offers']);
}

// Output the manipulated JSON
echo json_encode($data, JSON_PRETTY_PRINT);
?>

