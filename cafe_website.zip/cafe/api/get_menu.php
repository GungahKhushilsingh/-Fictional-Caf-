<?php
/**
 * PHP file to manipulate and serve XML menu data
 * Demonstrates XML manipulation using PHP DOM
 * 
 * This script reads the menu.xml file, manipulates it if needed,
 * and outputs it for AJAX requests
 */

header('Content-Type: application/xml; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate'); // Prevent caching

// Path to the XML file
$xmlFile = '../data/menu.xml';

// Check if file exists
if (!file_exists($xmlFile)) {
    http_response_code(404);
    echo '<?xml version="1.0" encoding="UTF-8"?><error>Menu file not found</error>';
    exit;
}

// Load XML file using DOMDocument
$dom = new DOMDocument('1.0', 'UTF-8');
$dom->preserveWhiteSpace = false;
$dom->formatOutput = true;

// Load the XML file
if (!$dom->load($xmlFile)) {
    http_response_code(500);
    echo '<?xml version="1.0" encoding="UTF-8"?><error>Failed to load XML file</error>';
    exit;
}

// Manipulate XML: Update last updated timestamp
$root = $dom->documentElement;
$root->setAttribute('lastUpdated', date('Y-m-d H:i:s'));

// Manipulate XML: Count items and add total count attribute
$xpath = new DOMXPath($dom);
$items = $xpath->query('//item');
$root->setAttribute('totalItems', $items->length);

// Output the XML
echo $dom->saveXML();
?>
