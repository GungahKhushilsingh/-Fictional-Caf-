<?php
/**
 * PHP file to get contact information from JSON data
 */

header('Content-Type: application/json; charset=utf-8');

$jsonFile = '../data/data.json';

if (!file_exists($jsonFile)) {
    http_response_code(404);
    echo json_encode(['error' => 'Data file not found']);
    exit;
}

$jsonData = file_get_contents($jsonFile);
$data = json_decode($jsonData, true);

if ($data === null || !isset($data['cafeInfo']['contact'])) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to load contact information']);
    exit;
}

// Return contact info and location
echo json_encode([
    'contact' => $data['cafeInfo']['contact'],
    'location' => $data['cafeInfo']['location'],
    'hours' => $data['cafeInfo']['hours']
], JSON_PRETTY_PRINT);
?>

