<?php
/**
 * get_offers_sql.php - Get offers from SQL database with JSON fallback
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');

try {
    require_once '../config/database.php';
    $pdo = getDBConnection();
    
    $sql = "SELECT id, title, description, category, discount_percentage as discountPercentage,
                   valid_from as validFrom, valid_until as validUntil
            FROM offers
            WHERE is_active = 1 AND (valid_until IS NULL OR valid_until >= CURDATE())
            ORDER BY valid_until ASC";
    
    $offers = fetchAll($sql);
    
    // Format for compatibility
    foreach ($offers as &$offer) {
        $offer['validUntil'] = $offer['validUntil'] ?? date('Y-m-d', strtotime('+1 year'));
        // Add default images based on category
        if ($offer['category'] === 'beverages') {
            $offer['image'] = 'image/happyhour.png';
        } elseif ($offer['category'] === 'all') {
            $offer['image'] = 'image/student.png';
        } elseif ($offer['category'] === 'desserts') {
            $offer['image'] = 'image/weekend.png';
        }
    }
    
    echo json_encode($offers, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    // Fallback to JSON
    $jsonFile = '../data/data.json';
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $data = json_decode($jsonData, true);
        if ($data && isset($data['offers'])) {
            echo json_encode($data['offers'], JSON_PRETTY_PRINT);
            exit;
        }
    }
    
    http_response_code(500);
    echo json_encode([
        'error' => 'Failed to load offers',
        'message' => $e->getMessage()
    ]);
}
?>

