<?php
/**
 * get_features_sql.php - Get features from SQL database
 */

header('Content-Type: application/json; charset=utf-8');

require_once '../config/database.php';

try {
    $pdo = getDBConnection();
    
    $sql = "SELECT id, title, description, icon, display_order 
            FROM features 
            WHERE is_active = 1 
            ORDER BY display_order";
    
    $features = fetchAll($sql);
    
    echo json_encode($features, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Database error',
        'message' => $e->getMessage()
    ]);
}
?>

