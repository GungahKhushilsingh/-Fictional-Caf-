<?php
/**
 * PHP file to get staff information from JSON data
 */

header('Content-Type: application/json; charset=utf-8');

$jsonFile = '../data/data.json';

if (!file_exists($jsonFile)) {
    http_response_code(404);
    echo json_encode(['error' => 'Data file not found']);
    exit;
}

$jsonData = file_get_contents($jsonFile);
$data = json_decode($jsonData, true);

if ($data === null || !isset($data['staff'])) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to load staff information']);
    exit;
}

echo json_encode($data['staff'], JSON_PRETTY_PRINT);
?>

