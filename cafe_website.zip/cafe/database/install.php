<?php
/**
 * install.php - Database installation script
 * Run this file once to set up the database
 * 
 * Usage: Open in browser: http://localhost/cafe/database/install.php
 */

// Allow direct access for installation
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Installation - Café Delight</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #6f4e37;
        }
        .success {
            color: #28a745;
            padding: 10px;
            background: #d4edda;
            border-radius: 5px;
            margin: 10px 0;
        }
        .error {
            color: #dc3545;
            padding: 10px;
            background: #f8d7da;
            border-radius: 5px;
            margin: 10px 0;
        }
        .info {
            color: #004085;
            padding: 10px;
            background: #d1ecf1;
            border-radius: 5px;
            margin: 10px 0;
        }
        button {
            background: #6f4e37;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #8b4513;
        }
        pre {
            background: #f4f4f4;
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>☕ Café Delight - Database Installation</h1>
        
        <?php
        // Database configuration
        $db_host = 'localhost';
        $db_user = 'root';
        $db_pass = ''; // Default XAMPP password
        $db_name = 'cafe_delight';
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['install'])) {
            try {
                // Connect to MySQL server (without database)
                $pdo = new PDO("mysql:host=$db_host;charset=utf8mb4", $db_user, $db_pass);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                echo '<div class="info">Connected to MySQL server successfully.</div>';
                
                // Read and execute SQL file
                $sql_file = __DIR__ . '/schema.sql';
                
                if (!file_exists($sql_file)) {
                    throw new Exception("SQL file not found: $sql_file");
                }
                
                $sql = file_get_contents($sql_file);
                
                // Split SQL file into individual statements
                $statements = array_filter(
                    array_map('trim', explode(';', $sql)),
                    function($statement) {
                        return !empty($statement) && 
                               !preg_match('/^(--|CREATE DATABASE|USE)/i', $statement);
                    }
                );
                
                // Execute each statement
                $executed = 0;
                $errors = [];
                
                foreach ($statements as $statement) {
                    try {
                        if (!empty(trim($statement))) {
                            $pdo->exec($statement);
                            $executed++;
                        }
                    } catch (PDOException $e) {
                        // Skip errors for existing objects
                        if (strpos($e->getMessage(), 'already exists') === false && 
                            strpos($e->getMessage(), 'Duplicate entry') === false) {
                            $errors[] = $e->getMessage();
                        }
                    }
                }
                
                echo '<div class="success">';
                echo '<strong>Installation completed successfully!</strong><br>';
                echo "Executed $executed SQL statements.<br>";
                echo '</div>';
                
                if (!empty($errors)) {
                    echo '<div class="error">';
                    echo '<strong>Some warnings occurred:</strong><br>';
                    echo '<pre>' . implode("\n", array_slice($errors, 0, 5)) . '</pre>';
                    if (count($errors) > 5) {
                        echo '<p>... and ' . (count($errors) - 5) . ' more warnings.</p>';
                    }
                    echo '</div>';
                }
                
                echo '<div class="info">';
                echo '<strong>Database is ready!</strong><br>';
                echo 'Default admin credentials:<br>';
                echo 'Username: <strong>admin</strong><br>';
                echo 'Password: <strong>admin123</strong><br><br>';
                echo '<a href="../admin/login.php"><button>Go to Admin Login</button></a>';
                echo '</div>';
                
            } catch (PDOException $e) {
                echo '<div class="error">';
                echo '<strong>Database Error:</strong><br>';
                echo htmlspecialchars($e->getMessage());
                echo '<br><br>Please ensure:';
                echo '<ul>';
                echo '<li>MySQL/MariaDB is running</li>';
                echo '<li>Default XAMPP credentials are correct (root / empty password)</li>';
                echo '<li>You have permission to create databases</li>';
                echo '</ul>';
                echo '</div>';
            } catch (Exception $e) {
                echo '<div class="error">';
                echo '<strong>Error:</strong><br>';
                echo htmlspecialchars($e->getMessage());
                echo '</div>';
            }
        } else {
            // Show installation form
            echo '<div class="info">';
            echo '<strong>Welcome to the Database Installation</strong><br><br>';
            echo 'This script will:';
            echo '<ul>';
            echo '<li>Create the database and all required tables</li>';
            echo '<li>Insert default data (admin user, menu items, categories, etc.)</li>';
            echo '<li>Set up default website settings</li>';
            echo '</ul>';
            echo '<br>';
            echo '<strong>Before proceeding, ensure:</strong>';
            echo '<ul>';
            echo '<li>XAMPP MySQL is running</li>';
            echo '<li>You have database creation privileges</li>';
            echo '<li>Default credentials are used (root / empty password)</li>';
            echo '</ul>';
            echo '</div>';
            
            echo '<form method="POST">';
            echo '<button type="submit" name="install" value="1">Install Database</button>';
            echo '</form>';
        }
        ?>
        
        <hr style="margin: 30px 0;">
        
        <div class="info">
            <strong>Manual Installation (Alternative):</strong><br>
            If automatic installation fails, you can manually run the SQL file:
            <ol>
                <li>Open phpMyAdmin: <a href="http://localhost/phpmyadmin" target="_blank">http://localhost/phpmyadmin</a></li>
                <li>Click on "Import" tab</li>
                <li>Choose file: <code>cafe/database/schema.sql</code></li>
                <li>Click "Go" to execute</li>
            </ol>
        </div>
    </div>
</body>
</html>

