-- Database Schema for Café Delight Website
-- Demonstrates SQL database integration
-- Run this file to create the database and tables

-- Create database (if it doesn't exist)
CREATE DATABASE IF NOT EXISTS cafe_delight CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE cafe_delight;

-- Table: admin_users
-- Stores admin user accounts
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: menu_items
-- Stores menu items (replaces/enhances XML menu data)
CREATE TABLE IF NOT EXISTS menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(10) DEFAULT 'USD',
    category_id INT,
    size VARCHAR(50),
    size_unit VARCHAR(20),
    calories INT,
    contains_caffeine BOOLEAN DEFAULT FALSE,
    is_popular BOOLEAN DEFAULT FALSE,
    is_available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category_id),
    INDEX idx_available (is_available),
    INDEX idx_popular (is_popular)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: categories
-- Menu item categories
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    slug VARCHAR(50) UNIQUE NOT NULL,
    type VARCHAR(50),
    description TEXT,
    display_order INT DEFAULT 0,
    is_available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: ingredients
-- Ingredients for menu items
CREATE TABLE IF NOT EXISTS ingredients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    menu_item_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE CASCADE,
    INDEX idx_menu_item (menu_item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: features
-- Website features (replaces JSON features array)
CREATE TABLE IF NOT EXISTS features (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(10),
    display_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_active (is_active),
    INDEX idx_order (display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: offers
-- Special offers (replaces JSON offers array)
CREATE TABLE IF NOT EXISTS offers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    category VARCHAR(50) DEFAULT 'all',
    discount_percentage DECIMAL(5, 2),
    valid_from DATE,
    valid_until DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_active (is_active),
    INDEX idx_valid_date (valid_until)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: staff
-- Staff members (replaces JSON staff array)
CREATE TABLE IF NOT EXISTS staff (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    position VARCHAR(50) NOT NULL,
    bio TEXT,
    years_of_service INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: staff_specialties
-- Staff specialties (many-to-many relationship)
CREATE TABLE IF NOT EXISTS staff_specialties (
    id INT AUTO_INCREMENT PRIMARY KEY,
    staff_id INT NOT NULL,
    specialty VARCHAR(100) NOT NULL,
    FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
    INDEX idx_staff (staff_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: reviews
-- Customer reviews
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    is_approved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_rating (rating),
    INDEX idx_approved (is_approved)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: contact_messages
-- Contact form submissions
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_read (is_read),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: cafe_settings
-- Website settings and contact information
CREATE TABLE IF NOT EXISTS cafe_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) UNIQUE NOT NULL,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: reservations
-- Customer table reservations
CREATE TABLE IF NOT EXISTS reservations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    reservation_date DATE NOT NULL,
    reservation_time TIME NOT NULL,
    guests INT NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_date (reservation_date),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default admin user (password: admin123, hashed)
-- Password hash for 'admin123' using PHP password_hash()
INSERT INTO admin_users (username, password, email) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@cafedelight.com')
ON DUPLICATE KEY UPDATE username=username;

-- Insert default categories
INSERT INTO categories (name, slug, type, description, display_order) VALUES
('Beverages', 'beverages', 'drinks', 'Hot and cold beverages', 1),
('Food', 'food', 'meals', 'Delicious meals and snacks', 2),
('Desserts', 'desserts', 'sweets', 'Sweet treats and desserts', 3)
ON DUPLICATE KEY UPDATE name=name;

-- Insert default features
INSERT INTO features (title, description, icon, display_order) VALUES
('Premium Coffee', 'We source the finest coffee beans from around the world', '☕', 1),
('Fresh Baked Goods', 'Daily fresh pastries and desserts baked in-house', '🥐', 2),
('Cozy Atmosphere', 'A warm and welcoming environment for everyone', '🛋️', 3),
('Free WiFi', 'Fast and free internet connection for all customers', '📶', 4)
ON DUPLICATE KEY UPDATE title=title;

-- Insert default offers
INSERT INTO offers (title, description, category, discount_percentage, valid_from, valid_until) VALUES
('Happy Hour', '20% off all beverages between 2 PM - 4 PM', 'beverages', 20.00, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 1 YEAR)),
('Student Discount', '15% off with valid student ID', 'all', 15.00, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 1 YEAR)),
('Weekend Special', 'Buy any dessert, get the second one at 50% off', 'desserts', 50.00, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 1 YEAR))
ON DUPLICATE KEY UPDATE title=title;

-- Insert default staff
INSERT INTO staff (name, position, bio, years_of_service) VALUES
('Sarah Johnson', 'Manager', 'Sarah brings passion and expertise to Café Delight, ensuring every customer has a wonderful experience.', 5),
('Michael Chen', 'Head Barista', 'Michael is a certified barista with years of experience crafting the perfect cup of coffee.', 4),
('Emily Rodriguez', 'Pastry Chef', 'Emily creates beautiful and delicious pastries that keep our customers coming back.', 3)
ON DUPLICATE KEY UPDATE name=name;

-- Insert staff specialties
INSERT INTO staff_specialties (staff_id, specialty) VALUES
(1, 'Customer Service'),
(1, 'Coffee Art'),
(2, 'Espresso'),
(2, 'Latte Art'),
(2, 'Coffee Roasting'),
(3, 'Pastries'),
(3, 'Desserts'),
(3, 'Baking')
ON DUPLICATE KEY UPDATE specialty=specialty;

-- Insert cafe settings
INSERT INTO cafe_settings (setting_key, setting_value) VALUES
('cafe_name', 'Café Delight'),
('founded_year', '2015'),
('phone', '+1 (555) 123-4567'),
('email', 'info@cafedelight.com'),
('address', '123 Main Street'),
('city', 'Springfield'),
('state', 'IL'),
('zip_code', '62701'),
('country', 'USA'),
('hours_monday', '7:00 AM - 8:00 PM'),
('hours_tuesday', '7:00 AM - 8:00 PM'),
('hours_wednesday', '7:00 AM - 8:00 PM'),
('hours_thursday', '7:00 AM - 9:00 PM'),
('hours_friday', '7:00 AM - 9:00 PM'),
('hours_saturday', '8:00 AM - 10:00 PM'),
('hours_sunday', '8:00 AM - 8:00 PM'),
('facebook_url', 'https://facebook.com/cafedelight'),
('instagram_url', 'https://instagram.com/cafedelight'),
('twitter_url', 'https://twitter.com/cafedelight')
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);

-- Insert default menu items with sample data
INSERT INTO menu_items (name, description, price, currency, category_id, size, size_unit, calories, contains_caffeine, is_popular) VALUES
('Espresso', 'Strong, concentrated coffee brewed by forcing hot water through finely ground coffee beans', 4.50, 'USD', 1, '30', 'ml', 5, TRUE, TRUE),
('Cappuccino', 'Espresso combined with steamed milk and milk foam, dusted with cocoa powder', 5.50, 'USD', 1, '150', 'ml', 80, TRUE, TRUE),
('Latte', 'Smooth espresso with steamed milk and a thin layer of foam', 5.00, 'USD', 1, '240', 'ml', 150, TRUE, FALSE),
('Americano', 'Espresso diluted with hot water, creating a coffee similar in strength to drip coffee', 4.00, 'USD', 1, '180', 'ml', 10, TRUE, FALSE),
('Mocha', 'Rich espresso combined with chocolate syrup, steamed milk, and whipped cream', 6.00, 'USD', 1, '240', 'ml', 290, TRUE, TRUE),
('Avocado Toast', 'Sourdough bread topped with mashed avocado, cherry tomatoes, feta cheese, and poached eggs', 8.50, 'USD', 2, '1', 'servings', 420, FALSE, TRUE),
('Club Sandwich', 'Triple-decker sandwich with turkey, bacon, lettuce, tomato, and mayo', 9.00, 'USD', 2, '1', 'servings', 650, FALSE, FALSE),
('Caesar Salad', 'Fresh romaine lettuce with Caesar dressing, croutons, and parmesan cheese', 7.50, 'USD', 2, '1', 'servings', 320, FALSE, TRUE),
('Chocolate Cake', 'Rich, moist chocolate cake with chocolate frosting', 5.50, 'USD', 3, '1', 'slice', 450, FALSE, TRUE),
('Cheesecake', 'Creamy New York-style cheesecake with graham cracker crust', 4.50, 'USD', 3, '1', 'slice', 380, FALSE, FALSE),
('Tiramisu', 'Classic Italian dessert with coffee-soaked ladyfingers and mascarpone cream', 6.00, 'USD', 3, '1', 'slice', 420, TRUE, TRUE)
ON DUPLICATE KEY UPDATE name=name;

-- Insert sample ingredients for menu items
INSERT INTO ingredients (menu_item_id, name) VALUES
(1, 'Arabica Coffee Beans'),
(1, 'Filtered Water'),
(2, 'Espresso'),
(2, 'Steamed Milk'),
(2, 'Milk Foam'),
(2, 'Cocoa Powder'),
(3, 'Espresso'),
(3, 'Steamed Milk'),
(3, 'Milk Foam'),
(4, 'Espresso'),
(4, 'Hot Water'),
(5, 'Espresso'),
(5, 'Chocolate Syrup'),
(5, 'Steamed Milk'),
(5, 'Whipped Cream'),
(6, 'Sourdough Bread'),
(6, 'Avocado'),
(6, 'Cherry Tomatoes'),
(6, 'Feta Cheese'),
(6, 'Poached Eggs'),
(6, 'Fresh Herbs')
ON DUPLICATE KEY UPDATE name=name;

-- Insert sample reviews
INSERT INTO reviews (customer_name, rating, comment, is_approved) VALUES
('John Doe', 5, 'Best coffee in town! The atmosphere is perfect for working or relaxing.', TRUE),
('Jane Smith', 5, 'Love the avocado toast and the friendly staff! Highly recommended.', TRUE),
('Robert Wilson', 4, 'Great place to meet friends. The desserts are amazing!', TRUE)
ON DUPLICATE KEY UPDATE customer_name=customer_name;

