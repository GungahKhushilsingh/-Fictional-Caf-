/**
 * menu.js - JavaScript for menu page
 * Demonstrates AJAX with XML parsing and DOM manipulation
 */

// Helper function to update status message
function updateMenuStatus(message) {
    const statusDiv = document.getElementById('menuStatus');
    if (statusDiv) {
        statusDiv.textContent = message;
        setTimeout(() => {
            statusDiv.textContent = '';
        }, 3000);
    }
}

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    loadMenu();
    
    // Add click handlers to filter buttons
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            // Update active state using DOM manipulation
            filterButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Allow manual refresh
    window.refreshMenu = function() {
        console.log('Manual menu refresh triggered');
        const container = document.getElementById('menuContainer');
        if (container) {
            container.innerHTML = '<p class="loading">Refreshing menu...</p>';
        }
        loadMenu();
    };
});

// Limited availability countdown (to midnight today)
(function(){
  function updateCountdown(){
    var el = document.getElementById('countdown');
    if(!el) return;
    var now = new Date();
    var end = new Date();
    end.setHours(23,59,59,999);
    var diff = end - now;
    if (diff <= 0) { el.textContent = '00:00:00'; return; }
    var h = Math.floor(diff/3600000);
    var m = Math.floor((diff%3600000)/60000);
    var s = Math.floor((diff%60000)/1000);
    el.textContent = String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
  }
  updateCountdown();
  setInterval(updateCountdown, 1000);
})();

/**
 * Load menu from SQL database first, fallback to XML
 * Demonstrates AJAX with JSON and XML parsing
 */
function loadMenu() {
    console.log('Loading menu...');
    // Try SQL/JSON API first
    const xhr = new XMLHttpRequest();
    
    // Add cache busting to prevent stale data
    xhr.open('GET', 'api/get_menu_sql.php?t=' + Date.now(), true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            console.log('API response status:', xhr.status);
            if (xhr.status === 200) {
                try {
                    console.log('Raw API response:', xhr.responseText.substring(0, 500));
                    // Try to parse as JSON (SQL response)
                    const data = JSON.parse(xhr.responseText);
                    console.log('Parsed JSON data:', data);
                    
                    if (data.error) {
                        console.error('Database error, falling back to XML:', data.message);
                        fallbackLoadXML();
                    } else {
                        console.log('Menu data loaded successfully. Categories:', data.menu?.length, 'Total items:', data.totalItems);
                        // Check if we have actual items (not just empty categories)
                        let hasItems = false;
                        if (data.menu && data.menu.length > 0) {
                            data.menu.forEach(cat => {
                                if (cat.items && cat.items.length > 0) {
                                    hasItems = true;
                                }
                            });
                        }
                        
                        if (hasItems) {
                            console.log('Displaying menu from SQL database');
                            updateMenuStatus('Loaded from database');
                            displayMenuFromJSON(data);
                        } else {
                            console.warn('SQL database is empty, falling back to XML');
                            updateMenuStatus('Database empty, loading from XML...');
                            fallbackLoadXML();
                        }
                    }
                } catch (e) {
                    console.error('Failed to parse JSON, falling back to XML:', e);
                    console.error('Response text:', xhr.responseText.substring(0, 500));
                    fallbackLoadXML();
                }
            } else {
                // SQL API failed, fallback to XML
                console.warn('SQL API failed, falling back to XML. Status:', xhr.status);
                fallbackLoadXML();
            }
        }
    };
    
    xhr.onerror = function() {
        console.error('XHR Error occurred, falling back to XML');
        fallbackLoadXML();
    };
    
    xhr.send();
}

/**
 * Load menu from XML API (fallback)
 */
function fallbackLoadXML() {
    console.log('Loading menu from XML...');
    const xhr = new XMLHttpRequest();
    
    // Add cache busting to ensure fresh XML
    xhr.open('GET', 'api/get_menu.php?t=' + Date.now(), true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('XML loaded successfully');
                // Parse XML response
                let xmlDoc = xhr.responseXML;
                
                if (!xmlDoc) {
                    // Fallback: parse as text if responseXML is null
                    const parser = new DOMParser();
                    xmlDoc = parser.parseFromString(xhr.responseText, 'text/xml');
                }
                
                // Check for parse errors
                const parserError = xmlDoc.querySelector('parsererror');
                if (parserError) {
                    console.error('XML Parse Error:', parserError.textContent);
                    fallbackLoadStaticXML('data/menu.xml');
                    return;
                }
                
                updateMenuStatus('Loaded from XML');
                displayMenu(xmlDoc);
            } else {
                console.warn('XML API failed, trying static file. Status:', xhr.status);
                // Final fallback: load static XML file
                fallbackLoadStaticXML('data/menu.xml');
            }
        }
    };
    
    xhr.onerror = function() {
        console.error('XHR Error loading XML, trying static file');
        fallbackLoadStaticXML('data/menu.xml');
    };
    
    xhr.send();
}

/**
 * Load menu from static XML file (final fallback)
 */
function fallbackLoadStaticXML(path) {
    const req = new XMLHttpRequest();
    req.open('GET', path, true);
    req.onreadystatechange = function() {
        if (req.readyState === 4) {
            if (req.status === 200) {
                let xmlDoc = req.responseXML;
                if (!xmlDoc) {
                    const parser = new DOMParser();
                    xmlDoc = parser.parseFromString(req.responseText, 'text/xml');
                }
                updateMenuStatus('Loaded from static XML file');
                displayMenu(xmlDoc);
            } else {
                const container = document.getElementById('menuContainer');
                if (container) {
                    container.innerHTML = '<p class="error">Menu is unavailable right now.</p>';
                }
                updateMenuStatus('Error loading menu');
            }
        }
    };
    req.send();
}

/**
 * Display menu items from JSON data (SQL database)
 * @param {Object} data - JSON data from SQL API
 */
function displayMenuFromJSON(data) {
    const container = document.getElementById('menuContainer');
    if (!container || !data.menu) {
        console.error('Invalid menu data:', data);
        return;
    }
    
    console.log('Displaying menu from JSON. Categories:', data.menu.length);
    container.innerHTML = '';
    
    let totalItemsDisplayed = 0;
    
    // Iterate through categories
    data.menu.forEach((category, categoryIndex) => {
        const categoryType = category.type || 'other';
        const categoryId = category.id || 'uncategorized';
        
        console.log(`Category ${categoryIndex + 1}: ${categoryId} - ${category.items?.length || 0} items`);
        
        // Get all items in this category
        if (!category.items || category.items.length === 0) {
            console.warn(`Skipping empty category: ${categoryId}`);
            return; // Skip empty categories
        }
        
        category.items.forEach((item, itemIndex) => {
            totalItemsDisplayed++;
            // Extract data from JSON
            const itemId = item.id || '';
            const price = item.price || '0';
            const currency = item.currency || 'USD';
            const popular = item.popular || false;
            const name = item.name || 'Unknown';
            const description = item.description || '';
            const size = item.size?.value || '';
            const sizeUnit = item.size?.unit || '';
            const calories = item.nutrition?.calories || '';
            const caffeine = item.nutrition?.caffeine || false;
            const image = item.image || ''; // Get image path from item
            
            // Debug: Log image information
            if (image) {
                console.log(`Item "${name}" has image:`, image);
            }
            
            // Create menu card using DOM manipulation
            const card = document.createElement('div');
            card.className = 'menu-item';
            card.setAttribute('data-category', categoryId);
            card.setAttribute('data-type', categoryType);
            
            // Add image if available
            if (image && image.trim() !== '') {
                const imageElement = document.createElement('img');
                // Ensure image path is correct (should be relative to root, like "image/americano.jpg")
                imageElement.src = image.startsWith('http') ? image : image;
                imageElement.alt = name;
                imageElement.className = 'menu-item-image';
                imageElement.style.cssText = 'width: 100%; height: 200px; object-fit: cover; border-radius: 8px 8px 0 0; display: block;';
                // Add error handling for broken images
                imageElement.onerror = function() {
                    console.warn('Image failed to load:', image);
                    this.style.display = 'none';
                };
                imageElement.onload = function() {
                    console.log('Image loaded successfully:', image);
                };
                // Insert image as first child of card
                card.insertBefore(imageElement, card.firstChild);
            }
            
            if (popular) {
                card.classList.add('popular');
                const popularBadge = document.createElement('span');
                popularBadge.className = 'popular-badge';
                popularBadge.textContent = 'Popular';
                card.appendChild(popularBadge);
            }
            
            const nameElement = document.createElement('h3');
            nameElement.textContent = name;
            
            const descriptionElement = document.createElement('p');
            descriptionElement.className = 'menu-description';
            descriptionElement.textContent = description;
            
            const priceElement = document.createElement('div');
            priceElement.className = 'menu-price';
            // Format price nicely and avoid duplicate symbols
            var symbol = (currency && currency !== '$') ? currency + ' ' : '$';
            priceElement.textContent = symbol + price;
            
            const sizeElement = document.createElement('span');
            sizeElement.className = 'menu-size';
            sizeElement.textContent = size + ' ' + sizeUnit;
            
            card.appendChild(nameElement);
            card.appendChild(descriptionElement);
            card.appendChild(document.createElement('br'));
            card.appendChild(sizeElement);
            card.appendChild(priceElement);
            
            // Optional background image per item - using CSS classes (only if no image is provided)
            if (!image) {
                const bgClass = getCardBackgroundClass(name, categoryId);
                if (bgClass) {
                    card.classList.add(bgClass);
                }
            }
            
            // Add to container
            container.appendChild(card);
            
            // Add fade-in animation
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            setTimeout(() => {
                card.style.transition = 'all 0.3s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, (categoryIndex * 100) + (itemIndex * 50));
        });
    });
    
    console.log(`Menu display complete. Total items displayed: ${totalItemsDisplayed}`);
    
    if (totalItemsDisplayed === 0) {
        console.error('No items were displayed! Check the data structure.');
        container.innerHTML = '<p class="error">No menu items found. Please check the admin panel.</p>';
    }
}


/**
 * Display menu items from XML using DOM manipulation
 * @param {Document} xmlDoc - Parsed XML document
 */
function displayMenu(xmlDoc) {
    const container = document.getElementById('menuContainer');
    if (!container) return;
    
    container.innerHTML = '';
    
    // Get all categories using DOM methods
    const categories = xmlDoc.getElementsByTagName('category');
    
    // Iterate through categories
    for (let i = 0; i < categories.length; i++) {
        const category = categories[i];
        const categoryType = category.getAttribute('type');
        const categoryId = category.getAttribute('id');
        
        // Get all items in this category
        const items = category.getElementsByTagName('item');
        
        // Create menu items for each item in the category
        for (let j = 0; j < items.length; j++) {
            const item = items[j];
            
            // Extract data from XML using DOM methods
            const itemId = item.getAttribute('id');
            const price = item.getAttribute('price');
            const currency = item.getAttribute('currency');
            const popular = item.getAttribute('popular') === 'true';
            
            const name = item.getElementsByTagName('name')[0]?.textContent || 'Unknown';
            const description = item.getElementsByTagName('description')[0]?.textContent || '';
            const size = item.getElementsByTagName('size')[0]?.textContent || '';
            const sizeUnit = item.getElementsByTagName('size')[0]?.getAttribute('unit') || '';
            
            // Create menu card using DOM manipulation
            const card = document.createElement('div');
            card.className = 'menu-item';
            card.setAttribute('data-category', categoryId);
            card.setAttribute('data-type', categoryType);
            
            if (popular) {
                card.classList.add('popular');
                const popularBadge = document.createElement('span');
                popularBadge.className = 'popular-badge';
                popularBadge.textContent = 'Popular';
                card.appendChild(popularBadge);
            }
            
            const nameElement = document.createElement('h3');
            nameElement.textContent = name;
            
            const descriptionElement = document.createElement('p');
            descriptionElement.className = 'menu-description';
            descriptionElement.textContent = description;
            
            const priceElement = document.createElement('div');
            priceElement.className = 'menu-price';
            // Format price nicely and avoid duplicate symbols
            var symbol = (currency && currency !== '$') ? currency + ' ' : '$';
            priceElement.textContent = symbol + price;
            
            const sizeElement = document.createElement('span');
            sizeElement.className = 'menu-size';
            sizeElement.textContent = size + ' ' + sizeUnit;
            
            card.appendChild(nameElement);
            card.appendChild(descriptionElement);
            card.appendChild(document.createElement('br'));
            card.appendChild(sizeElement);
            card.appendChild(priceElement);
            
            // Optional background image per item - using CSS classes
            const bgClass = getCardBackgroundClass(name, categoryId);
            if (bgClass) {
                card.classList.add(bgClass);
                console.log('Applied background class:', bgClass, 'to item:', name);
            }

            // Add to container
            container.appendChild(card);
            
            // Add fade-in animation
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            setTimeout(() => {
                card.style.transition = 'all 0.3s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, j * 50);
        }
    }
}

// Map item names to CSS background classes
function getCardBackgroundClass(itemName, categoryId){
  if(!itemName) return '';
  const key = itemName.toLowerCase().trim();
  console.log('Looking for background class for:', key);
  const map = {
    'espresso': 'menu-item-bg-espresso',
    'cappuccino': 'menu-item-bg-cappuccino',
    'latte': 'menu-item-bg-latte',
    'americano': 'menu-item-bg-americano',
    'mocha': 'menu-item-bg-mocha',
    'avocado toast': 'menu-item-bg-avocado-toast',
    'club sandwich': 'menu-item-bg-club-sandwich',
    'caesar salad': 'menu-item-bg-caesar-salad',
    'chocolate cake': 'menu-item-bg-chocolate-cake',
    'cheesecake': 'menu-item-bg-cheesecake',
    'tiramisu': 'menu-item-bg-tiramisu'
  };
  const result = map[key] || '';
  if(!result) {
    console.log('No background class found for:', key);
  }
  return result;
}

/**
 * Filter menu items by category
 * Demonstrates DOM manipulation for filtering
 * @param {string} category - Category to filter by
 */
function filterMenu(category) {
    const menuItems = document.querySelectorAll('.menu-item');
    
    menuItems.forEach(item => {
        if (category === 'all') {
            item.style.display = 'block';
            // Add animation
            item.style.opacity = '0';
            setTimeout(() => {
                item.style.opacity = '1';
            }, 50);
        } else {
            const itemCategory = item.getAttribute('data-category');
            if (itemCategory === category) {
                item.style.display = 'block';
                item.style.opacity = '0';
                setTimeout(() => {
                    item.style.opacity = '1';
                }, 50);
            } else {
                item.style.display = 'none';
            }
        }
    });
}

