/**
 * reservation.js - Reservation form handler
 * Separate file for reservation functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('.reservation-form');
    if (!form) return;
    
    const feedback = document.getElementById('res-feedback');
    
    function showMessage(type, text) {
        if (!feedback) return;
        
        const typeClass = type === 'error' ? 'error' : (type === 'info' ? 'info' : 'success');
        feedback.className = 'message ' + typeClass;
        feedback.textContent = text;
        feedback.style.display = 'block';
        
        if (type !== 'info') {
            setTimeout(function() {
                feedback.style.display = 'none';
            }, 5000);
        }
    }
    
    function isValidEmail(v) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v || '');
    }
    
    function isValidPhone(v) {
        return /^[0-9+\-\s()]{7,20}$/.test(v || '');
    }
    
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const name = document.getElementById('res-name').value.trim();
        const email = document.getElementById('res-email').value.trim();
        const phone = document.getElementById('res-phone').value.trim();
        const date = document.getElementById('res-date').value;
        const time = document.getElementById('res-time').value;
        const guests = parseInt(document.getElementById('res-guests').value, 10);
        
        // Validation
        if (!name) {
            showMessage('error', 'Please enter your full name.');
            return;
        }
        if (!isValidEmail(email)) {
            showMessage('error', 'Please enter a valid email address.');
            return;
        }
        if (!isValidPhone(phone)) {
            showMessage('error', 'Please enter a valid phone number.');
            return;
        }
        if (!date) {
            showMessage('error', 'Please select a reservation date.');
            return;
        }
        
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const selDate = new Date(date);
        selDate.setHours(0, 0, 0, 0);
        if (selDate < today) {
            showMessage('error', 'Reservation date cannot be in the past.');
            return;
        }
        
        if (!time) {
            showMessage('error', 'Please select a time.');
            return;
        }
        
        if (isNaN(guests) || guests < 1 || guests > 16) {
            showMessage('error', 'Guests must be between 1 and 16.');
            return;
        }
        
        // Disable submit button
        const submitButton = form.querySelector('button[type="submit"]');
        const originalText = submitButton ? submitButton.textContent : '';
        
        if (submitButton) {
            submitButton.disabled = true;
            submitButton.textContent = 'Submitting...';
        }
        
        // Show loading message
        showMessage('info', 'Submitting your reservation...');
        
        try {
            const formData = new FormData(form);
            
            console.log('Submitting reservation form...');
            
            const response = await fetch('api/submit_reservation.php', {
                method: 'POST',
                body: formData
            });
            
            console.log('Response status:', response.status);
            
            let data;
            try {
                const responseText = await response.text();
                console.log('Response text:', responseText);
                data = JSON.parse(responseText);
            } catch (parseError) {
                console.error('JSON parse error:', parseError);
                throw new Error('Invalid response from server. Please try again.');
            }
            
            if (!response.ok) {
                throw new Error(data.error || 'HTTP error! status: ' + response.status);
            }
            
            console.log('Response data:', data);
            
            if (data.success) {
                showMessage('success', data.message || 'Reservation received! We will confirm shortly.');
                form.reset();
            } else {
                showMessage('error', data.error || 'Failed to submit reservation. Please try again.');
            }
        } catch (error) {
            console.error('Reservation submission error:', error);
            showMessage('error', error.message || 'Network error. Please try again later.');
        } finally {
            if (submitButton) {
                submitButton.disabled = false;
                submitButton.textContent = originalText;
            }
        }
    });
});

