/**
 * about.js - JavaScript for about page
 * Demonstrates AJAX with JSON and DOM manipulation
 */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    loadStaff();
});

/**
 * Load staff information from JSON using AJAX
 */
function loadStaff() {
    // Try SQL API first, fallback to JSON
    fetch('api/get_staff_sql.php')
        .then(response => {
            if (!response.ok) throw new Error('SQL API failed');
            return response;
        })
        .catch(() => fetch('api/get_staff.php'))
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            const staffContainer = document.getElementById('staffContainer');
            
            if (!staffContainer || !Array.isArray(data)) {
                return;
            }
            
            staffContainer.innerHTML = '';
            
            // Create staff cards using DOM manipulation
            data.forEach(staff => {
                const card = document.createElement('div');
                card.className = 'staff-card';
                
                const name = document.createElement('h4');
                name.textContent = staff.name;
                
                const position = document.createElement('p');
                position.className = 'staff-position';
                position.textContent = staff.position;
                
                const years = document.createElement('p');
                years.className = 'staff-years';
                years.textContent = staff.yearsOfService + ' years of service';
                
                const bio = document.createElement('p');
                bio.className = 'staff-bio';
                bio.textContent = staff.bio;
                
                // Create specialties list
                if (staff.specialties && Array.isArray(staff.specialties)) {
                    const specialties = document.createElement('div');
                    specialties.className = 'staff-specialties';
                    
                    staff.specialties.forEach(specialty => {
                        const tag = document.createElement('span');
                        tag.className = 'specialty-tag';
                        tag.textContent = specialty;
                        specialties.appendChild(tag);
                    });
                    
                    card.appendChild(specialties);
                }
                
                // Append elements
                card.appendChild(name);
                card.appendChild(position);
                card.appendChild(years);
                card.appendChild(bio);
                
                staffContainer.appendChild(card);
            });
        })
        .catch(error => {
            console.error('Error loading staff:', error);
            const staffContainer = document.getElementById('staffContainer');
            if (staffContainer) {
                staffContainer.innerHTML = '<p class="error">Failed to load staff information.</p>';
            }
        });
}

