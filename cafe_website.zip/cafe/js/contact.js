/**
 * contact.js - JavaScript for contact page
 * Demonstrates AJAX with JSON and DOM manipulation, form handling
 */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    loadContactInfo();
});

/**
 * Load contact information from JSON using AJAX
 */
function loadContactInfo() {
    fetch('api/get_contact.php')
        .then(response => response.json())
        .then(data => {
            const contactDetails = document.getElementById('contactDetails');
            
            if (!contactDetails) return;
            
            // Create contact information display using DOM manipulation
            const phone = document.createElement('div');
            phone.className = 'contact-item';
            phone.innerHTML = '<strong>Phone:</strong> ' + data.contact.phone;
            
            const email = document.createElement('div');
            email.className = 'contact-item';
            email.innerHTML = '<strong>Email:</strong> ' + data.contact.email;
            
            const address = document.createElement('div');
            address.className = 'contact-item';
            address.innerHTML = '<strong>Address:</strong> ' + 
                data.location.address + ', ' + 
                data.location.city + ', ' + 
                data.location.state + ' ' + 
                data.location.zipCode;
            
            // Create hours display
            const hoursTitle = document.createElement('h4');
            hoursTitle.textContent = 'Opening Hours';
            
            const hoursList = document.createElement('ul');
            hoursList.className = 'hours-list';
            
            Object.keys(data.hours).forEach(day => {
                const li = document.createElement('li');
                li.innerHTML = '<strong>' + day.charAt(0).toUpperCase() + day.slice(1) + ':</strong> ' + data.hours[day];
                hoursList.appendChild(li);
            });
            
            // Clear and append
            contactDetails.innerHTML = '';
            contactDetails.appendChild(phone);
            contactDetails.appendChild(email);
            contactDetails.appendChild(address);
            contactDetails.appendChild(hoursTitle);
            contactDetails.appendChild(hoursList);
        })
        .catch(error => {
            console.error('Error loading contact info:', error);
            const contactDetails = document.getElementById('contactDetails');
            if (contactDetails) {
                contactDetails.innerHTML = '<p class="error">Failed to load contact information.</p>';
            }
        });
}

/**
 * Handle form submission using AJAX
 * @param {Event} event - Form submit event
 */
function submitForm(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    const responseDiv = document.getElementById('formResponse');
    
    // Clear previous response
    if (responseDiv) {
        responseDiv.innerHTML = '';
        responseDiv.className = '';
    }
    
    // Show loading state using DOM manipulation
    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.disabled = true;
    submitButton.textContent = 'Sending...';
    
    // Submit form via AJAX
    fetch('api/submit_contact.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        // DOM manipulation: Update response message
        if (responseDiv) {
            if (data.success) {
                responseDiv.className = 'success-message';
                responseDiv.textContent = data.message;
                form.reset(); // Reset form on success
            } else {
                responseDiv.className = 'error-message';
                responseDiv.textContent = data.error || 'An error occurred. Please try again.';
            }
        }
    })
    .catch(error => {
        console.error('Error submitting form:', error);
        if (responseDiv) {
            responseDiv.className = 'error-message';
            responseDiv.textContent = 'Network error. Please try again later.';
        }
    })
    .finally(() => {
        // Reset button state
        submitButton.disabled = false;
        submitButton.textContent = originalText;
    });
}

