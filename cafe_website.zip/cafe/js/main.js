/**
 * main.js - Main JavaScript file for homepage
 * Demonstrates AJAX (fetch API) and DOM manipulation
 */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // loadFeatures(); // Replaced with static story section
    loadOffers();
    loadDynamicContent();
});

/**
 * Load features from JSON using AJAX
 * Demonstrates fetch API (modern AJAX)
 */
function loadFeatures() {
    fetch('api/get_features.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // DOM manipulation: Create and insert feature cards
            const featuresGrid = document.getElementById('featuresGrid');
            
            if (!featuresGrid || !Array.isArray(data)) {
                return;
            }
            
            // Clear loading message
            featuresGrid.innerHTML = '';
            
            // Create feature cards using DOM manipulation
            data.forEach(feature => {
                const card = document.createElement('div');
                card.className = 'feature-card';
                
                const icon = document.createElement('div');
                icon.className = 'feature-icon';
                icon.textContent = feature.icon;
                
                const title = document.createElement('h3');
                title.textContent = feature.title;
                
                const description = document.createElement('p');
                description.textContent = feature.description;
                
                // Append elements using DOM manipulation
                card.appendChild(icon);
                card.appendChild(title);
                card.appendChild(description);
                
                // Add animation
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                featuresGrid.appendChild(card);
                
                // Animate in
                setTimeout(() => {
                    card.style.transition = 'all 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 100);
            });
        })
        .catch(error => {
            console.error('Error loading features:', error);
            const featuresGrid = document.getElementById('featuresGrid');
            if (featuresGrid) {
                featuresGrid.innerHTML = '<p class="error">Failed to load features. Please try again later.</p>';
            }
        });
}

/**
 * Load offers from JSON using AJAX
 */
function loadOffers() {
    // Try SQL API first, fallback to JSON
    fetch('api/get_offers_sql.php')
        .then(response => {
            if (!response.ok) throw new Error('SQL API failed');
            return response.json();
        })
        .catch(() => fetch('api/get_offers.php').then(r => r.json()))
        .then(data => {
            const offersContainer = document.getElementById('offersContainer');
            
            if (!offersContainer || !Array.isArray(data)) {
                return;
            }
            
            offersContainer.innerHTML = '';
            
            // Create offer cards using DOM manipulation
            data.forEach(offer => {
                const card = document.createElement('div');
                card.className = 'offer-card';
                
                // Create image container if image is provided
                if (offer.image) {
                    const imageContainer = document.createElement('div');
                    imageContainer.className = 'offer-image-container';
                    
                    const img = document.createElement('img');
                    img.src = offer.image;
                    img.alt = offer.title || 'Special Offer';
                    img.className = 'offer-image';
                    
                    imageContainer.appendChild(img);
                    card.appendChild(imageContainer);
                }
                
                // Create content container
                const contentContainer = document.createElement('div');
                contentContainer.className = 'offer-content';
                
                const title = document.createElement('h3');
                title.textContent = offer.title;
                
                const description = document.createElement('p');
                description.textContent = offer.description;
                
                contentContainer.appendChild(title);
                contentContainer.appendChild(description);
                
                card.appendChild(contentContainer);
                offersContainer.appendChild(card);
            });
        })
        .catch(error => {
            console.error('Error loading offers:', error);
            const offersContainer = document.getElementById('offersContainer');
            if (offersContainer) {
                offersContainer.innerHTML = '<p class="error">Failed to load offers.</p>';
            }
        });
}

/**
 * Load dynamic content using AJAX
 */
function loadDynamicContent() {
    fetch('api/get_data.php')
        .then(response => response.json())
        .then(data => {
            // DOM manipulation: Update footer with dynamic content
            const dynamicContent = document.getElementById('dynamicContent');
            if (dynamicContent && data.averageRating) {
                dynamicContent.textContent = `Average Rating: ${data.averageRating} ⭐ | ${data.totalStaff || 0} Staff Members | ${data.totalOffers || 0} Active Offers`;
            }
        })
        .catch(error => {
            console.error('Error loading dynamic content:', error);
        });
}

// Animate elements on scroll
function revealOnScroll() {
    var reveals = document.querySelectorAll('.feature-card, .offer-card, .menu-item, .staff-card, .hero-content, .footer');
    for (var i = 0; i < reveals.length; i++) {
        var windowHeight = window.innerHeight;
        var elementTop = reveals[i].getBoundingClientRect().top;
        var elementVisible = 60;
        if (elementTop < windowHeight - elementVisible) {
            reveals[i].classList.add('is-visible');
        } else {
            reveals[i].classList.remove('is-visible');
        }
    }
}
window.addEventListener('scroll', revealOnScroll);
document.addEventListener('DOMContentLoaded', revealOnScroll);

// Newsletter subscription
function subscribeNewsletter(event) {
    event.preventDefault();
    const form = event.target;
    const email = form.querySelector('input[type="email"]').value;
    const messageDiv = document.getElementById('newsletterMessage');
    
    if (messageDiv) {
        messageDiv.textContent = 'Subscribing...';
        messageDiv.style.color = '#6f4e37';
    }
    
    // Simple client-side subscription (could be extended to save to database)
    setTimeout(() => {
        if (messageDiv) {
            messageDiv.textContent = '✓ Thank you for subscribing!';
            messageDiv.style.color = '#28a745';
        }
        form.reset();
        setTimeout(() => {
            if (messageDiv) messageDiv.textContent = '';
        }, 3000);
    }, 500);
}

// Reservation form validation
(function(){
  document.addEventListener('DOMContentLoaded', function(){
    var form = document.querySelector('.reservation-form');
    if(!form) return;
    var feedback = document.getElementById('res-feedback');

    function showMessage(type, text){
      if(!feedback) return;
      // Support 'info' type for loading messages
      var typeClass = type === 'error' ? 'error' : (type === 'info' ? 'info' : 'success');
      feedback.className = 'message ' + typeClass;
      feedback.textContent = text;
      feedback.style.display = 'block';
      // Don't auto-hide info messages, only success/error
      if (type !== 'info') {
        setTimeout(function(){ feedback.style.display='none'; }, 5000);
      }
    }

    function isValidEmail(v){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v || ''); }
    function isValidPhone(v){ return /^[0-9+\-\s()]{7,20}$/.test(v || ''); }

    form.addEventListener('submit', function(e){
      e.preventDefault();
      var name = document.getElementById('res-name').value.trim();
      var email = document.getElementById('res-email').value.trim();
      var phone = document.getElementById('res-phone').value.trim();
      var date = document.getElementById('res-date').value;
      var time = document.getElementById('res-time').value;
      var guests = parseInt(document.getElementById('res-guests').value, 10);

      // Basic checks
      if(!name){ showMessage('error','Please enter your full name.'); return; }
      if(!isValidEmail(email)){ showMessage('error','Please enter a valid email address.'); return; }
      if(!isValidPhone(phone)){ showMessage('error','Please enter a valid phone number.'); return; }
      if(!date){ showMessage('error','Please select a reservation date.'); return; }
      var today = new Date(); today.setHours(0,0,0,0);
      var selDate = new Date(date); selDate.setHours(0,0,0,0);
      if(selDate < today){ showMessage('error','Reservation date cannot be in the past.'); return; }
      if(!time){ showMessage('error','Please select a time.'); return; }
      if(isNaN(guests) || guests < 1 || guests > 16){ showMessage('error','Guests must be between 1 and 16.'); return; }

      // Submit reservation via AJAX - Using async/await (proven to work)
      const submitButton = form.querySelector('button[type="submit"]');
      const originalText = submitButton ? submitButton.textContent : '';
      
      if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = 'Submitting...';
      }
      
      // Show loading message
      showMessage('info', 'Submitting your reservation...');
      
      // Use async/await for cleaner error handling
      (async function() {
        try {
          const formData = new FormData(form);
          
          const response = await fetch('api/submit_reservation.php', {
            method: 'POST',
            body: formData
          });
          
          const data = await response.json();
          
          if (data.success) {
            showMessage('success', data.message || 'Reservation received! We will confirm shortly.');
            form.reset();
          } else {
            showMessage('error', data.error || 'Failed to submit reservation. Please try again.');
          }
        } catch (error) {
          console.error('Reservation submission error:', error);
          showMessage('error', 'Network error. Please try again later.');
        } finally {
          if (submitButton) {
            submitButton.disabled = false;
            submitButton.textContent = originalText;
          }
        }
      })();
    });
  });
})();

