/**
 * admin.js - JavaScript for admin panel
 * Handles admin interface interactions and enhancements
 */

document.addEventListener('DOMContentLoaded', function() {
    // Add smooth animations to cards
    animateCards();
    
    // Add form validation enhancements
    enhanceForms();
});

/**
 * Animate cards on page load
 */
function animateCards() {
    const cards = document.querySelectorAll('.stat-card, .action-card, .menu-item-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 50);
    });
}

/**
 * Enhance form validation and user experience
 */
function enhanceForms() {
    const forms = document.querySelectorAll('.admin-form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            // Add basic client-side validation feedback
            const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
            let isValid = true;
            
            inputs.forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                    input.style.borderColor = '#dc3545';
                    
                    setTimeout(() => {
                        input.style.borderColor = '#e0e0e0';
                    }, 2000);
                } else {
                    input.style.borderColor = '#28a745';
                    
                    setTimeout(() => {
                        input.style.borderColor = '#e0e0e0';
                    }, 1000);
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Please fill in all required fields');
            }
        });
    });
}

