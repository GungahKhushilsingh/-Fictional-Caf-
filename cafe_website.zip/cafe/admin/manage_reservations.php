<?php
/**
 * manage_reservations.php - Admin page to view and manage reservations
 */

require_once 'auth_check.php';
require_once '../config/database.php';

$message = '';
$messageType = '';

// Handle form submissions (update status, delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    try {
        $pdo = getDBConnection();
        $action = $_POST['action'];
        
        if ($action === 'update_status') {
            $reservationId = intval($_POST['reservation_id']);
            $newStatus = $_POST['status'];
            
            $sql = "UPDATE reservations SET status = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$newStatus, $reservationId]);
            
            $message = 'Reservation status updated successfully!';
            $messageType = 'success';
            
        } elseif ($action === 'delete_reservation') {
            $reservationId = intval($_POST['reservation_id']);
            
            $sql = "DELETE FROM reservations WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$reservationId]);
            
            $message = 'Reservation deleted successfully!';
            $messageType = 'success';
        }
    } catch (Exception $e) {
        $message = 'Error: ' . $e->getMessage();
        $messageType = 'error';
    }
}

// Load reservations from database
try {
    $pdo = getDBConnection();
    
    // Check if table exists, create if it doesn't
    $checkTable = $pdo->query("SHOW TABLES LIKE 'reservations'");
    $tableExists = $checkTable->rowCount() > 0;
    
    if (!$tableExists) {
        // Create table
        $createTableSql = "CREATE TABLE IF NOT EXISTS reservations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            reservation_date DATE NOT NULL,
            reservation_time TIME NOT NULL,
            guests INT NOT NULL,
            status VARCHAR(20) DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_date (reservation_date),
            INDEX idx_status (status),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        
        $pdo->exec($createTableSql);
    }
    
    // Get filter
    $statusFilter = isset($_GET['status']) ? $_GET['status'] : 'all';
    
    // Build query
    if ($statusFilter === 'all') {
        $sql = "SELECT * FROM reservations ORDER BY reservation_date DESC, reservation_time DESC, created_at DESC";
        $reservations = fetchAll($sql);
    } else {
        $sql = "SELECT * FROM reservations WHERE status = ? ORDER BY reservation_date DESC, reservation_time DESC, created_at DESC";
        $reservations = fetchAll($sql, [$statusFilter]);
    }
    
    if ($reservations === false) {
        $reservations = [];
    }
    
    // Get statistics with error handling
    try {
        $totalResult = fetchOne("SELECT COUNT(*) as count FROM reservations");
        $pendingResult = fetchOne("SELECT COUNT(*) as count FROM reservations WHERE status = 'pending'");
        $confirmedResult = fetchOne("SELECT COUNT(*) as count FROM reservations WHERE status = 'confirmed'");
        $cancelledResult = fetchOne("SELECT COUNT(*) as count FROM reservations WHERE status = 'cancelled'");
        
        $stats = [
            'total' => $totalResult['count'] ?? 0,
            'pending' => $pendingResult['count'] ?? 0,
            'confirmed' => $confirmedResult['count'] ?? 0,
            'cancelled' => $cancelledResult['count'] ?? 0
        ];
    } catch (Exception $e) {
        $stats = ['total' => 0, 'pending' => 0, 'confirmed' => 0, 'cancelled' => 0];
        error_log("Error getting stats: " . $e->getMessage());
    }
    
} catch (PDOException $e) {
    $reservations = [];
    $stats = ['total' => 0, 'pending' => 0, 'confirmed' => 0, 'cancelled' => 0];
    $message = 'Database error loading reservations: ' . $e->getMessage();
    $messageType = 'error';
    error_log("Reservations page database error: " . $e->getMessage());
} catch (Exception $e) {
    $reservations = [];
    $stats = ['total' => 0, 'pending' => 0, 'confirmed' => 0, 'cancelled' => 0];
    $message = 'Error loading reservations: ' . $e->getMessage();
    $messageType = 'error';
    error_log("Reservations page error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Reservations - Admin Panel</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 0.85em;
            font-weight: 600;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-confirmed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        .status-completed { background: #d1ecf1; color: #0c5460; }
        
        .filter-tabs {
            display: flex;
            gap: 10px;
            margin: 20px 0;
            flex-wrap: wrap;
        }
        .filter-tab {
            padding: 8px 16px;
            background: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s;
        }
        .filter-tab:hover {
            background: #e9e9e9;
        }
        .filter-tab.active {
            background: #6f4e37;
            color: white;
            border-color: #6f4e37;
        }
        
        .reservation-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background: white;
        }
        .reservation-table th {
            background: #6f4e37;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }
        .reservation-table td {
            padding: 12px;
            border-bottom: 1px solid #e0e0e0;
            color: #2c3e50 !important;
            background: white;
            font-weight: 400;
        }
        .reservation-table tr:hover {
            background: #f9f9f9;
        }
        .reservation-table tr:hover td {
            background: #f9f9f9;
        }
        .reservation-table td strong {
            color: #1a1a1a !important;
            font-weight: 600;
        }
        .reservation-table td div {
            color: #2c3e50 !important;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        .btn-small {
            padding: 4px 12px;
            font-size: 0.85em;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-confirm { background: #28a745; color: white; }
        .btn-cancel { background: #dc3545; color: white; }
        .btn-delete { background: #6c757d; color: white; }
        
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #999;
        }
    </style>
</head>
<body class="admin-body">
    <!-- Admin Navigation -->
    <nav class="admin-nav">
        <div class="admin-nav-container">
            <div class="admin-logo">
                <h2>☕ Admin Panel</h2>
            </div>
            <div class="admin-nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="manage_sql.php">Manage Menu</a>
                <a href="manage_data.php">Manage Data</a>
                <a href="manage_reservations.php" class="active">Reservations</a>
                <a href="../index.php" target="_blank">View Website</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="admin-container">
        <div class="admin-header">
            <h1>Reservation Management</h1>
            <p>View and manage customer table reservations</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="admin-section">
            <h2>Reservation Statistics</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">📅</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['total']; ?></h3>
                        <p>Total Reservations</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['pending']; ?></h3>
                        <p>Pending</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">✓</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['confirmed']; ?></h3>
                        <p>Confirmed</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">✗</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['cancelled']; ?></h3>
                        <p>Cancelled</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter Tabs -->
        <div class="admin-section">
            <h2>All Reservations</h2>
            <div class="filter-tabs">
                <a href="?status=all" class="filter-tab <?php echo $statusFilter === 'all' ? 'active' : ''; ?>">All</a>
                <a href="?status=pending" class="filter-tab <?php echo $statusFilter === 'pending' ? 'active' : ''; ?>">Pending</a>
                <a href="?status=confirmed" class="filter-tab <?php echo $statusFilter === 'confirmed' ? 'active' : ''; ?>">Confirmed</a>
                <a href="?status=cancelled" class="filter-tab <?php echo $statusFilter === 'cancelled' ? 'active' : ''; ?>">Cancelled</a>
            </div>

            <?php if (empty($reservations)): ?>
                <div class="empty-state">
                    <p style="font-size: 1.2em; margin-bottom: 10px;">📭 No reservations found</p>
                    <p>When customers submit reservations, they will appear here.</p>
                </div>
            <?php else: ?>
                <table class="reservation-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>Contact</th>
                            <th>Date & Time</th>
                            <th>Guests</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reservations as $res): ?>
                            <tr>
                                <td style="color: #2c3e50 !important; font-weight: 600;"><?php echo htmlspecialchars($res['id']); ?></td>
                                <td style="color: #1a1a1a !important; font-weight: 600;"><strong><?php echo htmlspecialchars($res['name']); ?></strong></td>
                                <td style="color: #2c3e50;">
                                    <div style="color: #2c3e50;"><?php echo htmlspecialchars($res['email']); ?></div>
                                    <div style="font-size: 0.9em; color: #555;"><?php echo htmlspecialchars($res['phone']); ?></div>
                                </td>
                                <td style="color: #2c3e50;">
                                    <div><strong style="color: #1a1a1a;"><?php echo date('M d, Y', strtotime($res['reservation_date'])); ?></strong></div>
                                    <div style="font-size: 0.9em; color: #555;"><?php echo date('g:i A', strtotime($res['reservation_time'])); ?></div>
                                </td>
                                <td style="color: #2c3e50;"><?php echo htmlspecialchars($res['guests']); ?> guest<?php echo $res['guests'] > 1 ? 's' : ''; ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo htmlspecialchars($res['status']); ?>">
                                        <?php echo ucfirst(htmlspecialchars($res['status'])); ?>
                                    </span>
                                </td>
                                <td style="color: #2c3e50;"><?php echo date('M d, Y g:i A', strtotime($res['created_at'])); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <?php if ($res['status'] === 'pending'): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="update_status">
                                                <input type="hidden" name="reservation_id" value="<?php echo $res['id']; ?>">
                                                <input type="hidden" name="status" value="confirmed">
                                                <button type="submit" class="btn-small btn-confirm" onclick="return confirm('Confirm this reservation?')">Confirm</button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <?php if ($res['status'] !== 'cancelled'): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="update_status">
                                                <input type="hidden" name="reservation_id" value="<?php echo $res['id']; ?>">
                                                <input type="hidden" name="status" value="cancelled">
                                                <button type="submit" class="btn-small btn-cancel" onclick="return confirm('Cancel this reservation?')">Cancel</button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this reservation? This cannot be undone.');">
                                            <input type="hidden" name="action" value="delete_reservation">
                                            <input type="hidden" name="reservation_id" value="<?php echo $res['id']; ?>">
                                            <button type="submit" class="btn-small btn-delete">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <script src="../js/admin.js"></script>
</body>
</html>

