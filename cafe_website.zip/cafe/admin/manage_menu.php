<?php
/**
 * manage_menu.php - Admin page to manage menu items in XML
 * Demonstrates PHP XML manipulation
 */
require_once 'auth_check.php';

$xmlFile = '../data/menu.xml';
$message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        // Load XML
        $xml = new DOMDocument('1.0', 'UTF-8');
        $xml->preserveWhiteSpace = false;
        $xml->formatOutput = true;
        $xml->load($xmlFile);
        
        if ($action === 'add') {
            // Add new menu item
            $categoryId = $_POST['category_id'];
            $itemId = time(); // Simple ID generation
            
            $xpath = new DOMXPath($xml);
            $categories = $xpath->query("//category[@id='$categoryId']");
            
            if ($categories->length > 0) {
                $category = $categories->item(0);
                
                // Escape HTML special characters in user input
                $name = htmlspecialchars(trim($_POST['name']), ENT_XML1, 'UTF-8');
                $description = htmlspecialchars(trim($_POST['description']), ENT_XML1, 'UTF-8');
                
                $item = $xml->createElement('item');
                $item->setAttribute('id', $itemId);
                $item->setAttribute('price', $_POST['price']);
                $item->setAttribute('currency', $_POST['currency']);
                $item->setAttribute('popular', $_POST['popular']);
                
                $nameElement = $xml->createElement('name', $name);
                $descriptionElement = $xml->createElement('description', $description);
                $size = $xml->createElement('size', $_POST['size']);
                $size->setAttribute('unit', $_POST['size_unit']);
                
                $ingredients = $xml->createElement('ingredients');
                $ingredientList = explode(',', $_POST['ingredients']);
                foreach ($ingredientList as $ing) {
                    $ingredient = $xml->createElement('ingredient', trim($ing));
                    $ingredients->appendChild($ingredient);
                }
                
                $nutrition = $xml->createElement('nutrition');
                $nutrition->setAttribute('calories', $_POST['calories']);
                $nutrition->setAttribute('caffeine', $_POST['caffeine']);
                
                $item->appendChild($nameElement);
                $item->appendChild($descriptionElement);
                $item->appendChild($size);
                $item->appendChild($ingredients);
                $item->appendChild($nutrition);
                
                $category->appendChild($item);
                
                // Save XML file
                if ($xml->save($xmlFile)) {
                    $message = 'Menu item added successfully! The menu will refresh automatically.';
                } else {
                    $message = 'Error: Could not save menu file. Please check file permissions.';
                }
            } else {
                $message = 'Error: Category not found. Please select a valid category.';
            }
        } elseif ($action === 'delete') {
            // Delete menu item
            $itemId = $_POST['item_id'];
            $xpath = new DOMXPath($xml);
            $items = $xpath->query("//item[@id='$itemId']");
            
            if ($items->length > 0) {
                $item = $items->item(0);
                $item->parentNode->removeChild($item);
                $xml->save($xmlFile);
                $message = 'Menu item deleted successfully!';
            }
        }
    }
}

// Load current menu
$xml = simplexml_load_file($xmlFile);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Menu - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body class="admin-body">
    <nav class="admin-nav">
        <div class="admin-nav-container">
            <div class="admin-logo">
                <h2>☕ Admin Panel</h2>
            </div>
            <div class="admin-nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="manage_menu.php" class="active">Manage Menu</a>
                <a href="manage_data.php">Manage Data</a>
                <a href="../index.php" target="_blank">View Website</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="admin-container">
        <div class="admin-header">
            <h1>Manage Menu Items</h1>
            <p>Add, edit, or remove items from your café menu</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($message); ?>
                <br><br>
                <a href="../menu.php" target="_blank" style="color: white; text-decoration: underline; font-weight: bold;">→ View Menu Page</a>
            </div>
        <?php endif; ?>

        <!-- Add New Item Form -->
        <div class="admin-section">
            <h2>Add New Menu Item</h2>
            <form method="POST" class="admin-form">
                <input type="hidden" name="action" value="add">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Category</label>
                        <select name="category_id" required>
                            <option value="beverages">Beverages</option>
                            <option value="food">Food</option>
                            <option value="desserts">Desserts</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="name" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="3" required></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Price</label>
                        <input type="number" name="price" step="0.01" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Currency</label>
                        <input type="text" name="currency" value="USD" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Size</label>
                        <input type="text" name="size" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Size Unit</label>
                        <input type="text" name="size_unit" value="ml" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Ingredients (comma-separated)</label>
                        <input type="text" name="ingredients" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Calories</label>
                        <input type="number" name="calories" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Contains Caffeine</label>
                        <select name="caffeine">
                            <option value="true">Yes</option>
                            <option value="false">No</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Popular Item</label>
                        <select name="popular">
                            <option value="true">Yes</option>
                            <option value="false">No</option>
                        </select>
                    </div>
                </div>
                
                <button type="submit" class="btn-admin">Add Menu Item</button>
            </form>
        </div>

        <!-- Current Menu Items -->
        <div class="admin-section">
            <h2>Current Menu Items</h2>
            <div class="menu-list">
                <?php foreach ($xml->category as $category): ?>
                    <div class="category-group">
                        <h3 class="category-title"><?php echo ucfirst($category['id']); ?></h3>
                        <div class="items-grid">
                            <?php foreach ($category->item as $item): ?>
                                <div class="menu-item-card">
                                    <div class="menu-item-header">
                                        <h4><?php echo htmlspecialchars($item->name); ?></h4>
                                        <span class="menu-price">$<?php echo $item['price']; ?></span>
                                    </div>
                                    <p class="menu-item-desc"><?php echo htmlspecialchars($item->description); ?></p>
                                    <div class="menu-item-actions">
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this item?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                                            <button type="submit" class="btn-delete">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script src="../js/admin.js"></script>
</body>
</html>

