<?php
/**
 * manage_sql.php - Admin page to manage data using SQL database
 * Demonstrates PHP SQL database manipulation
 */
require_once 'auth_check.php';
require_once '../config/database.php';

$message = '';
$messageType = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    try {
        $pdo = getDBConnection();
        
        if ($action === 'add_menu_item') {
            // Validate required fields
            $requiredFields = ['name', 'description', 'price', 'category_id', 'size', 'calories'];
            $missingFields = [];
            foreach ($requiredFields as $field) {
                if (empty($_POST[$field])) {
                    $missingFields[] = $field;
                }
            }
            
            if (!empty($missingFields)) {
                throw new Exception('Missing required fields: ' . implode(', ', $missingFields));
            }
            
            // Validate category exists
            $categoryCheck = fetchOne("SELECT id FROM categories WHERE id = ? AND is_available = 1", [$_POST['category_id']]);
            if (!$categoryCheck) {
                throw new Exception('Invalid or unavailable category selected. Category ID: ' . intval($_POST['category_id']));
            }
            
            // Add new menu item to database
            // Explicitly set is_available = 1 to ensure items show up
            // First check if image column exists, if not add it
            try {
                $checkImage = $pdo->query("SHOW COLUMNS FROM menu_items LIKE 'image'");
                if ($checkImage->rowCount() == 0) {
                    $pdo->exec("ALTER TABLE menu_items ADD COLUMN image VARCHAR(255) DEFAULT NULL AFTER description");
                }
            } catch (Exception $e) {
                // Column might already exist or table doesn't exist yet
            }
            
            $sql = "INSERT INTO menu_items (name, description, price, currency, category_id, size, size_unit, calories, contains_caffeine, is_popular, is_available, image) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)";
            
            $imagePath = !empty($_POST['image']) ? trim($_POST['image']) : null;
            if ($imagePath && !empty($imagePath)) {
                // Ensure it starts with 'image/'
                if (strpos($imagePath, 'image/') !== 0) {
                    $imagePath = 'image/' . $imagePath;
                }
            } else {
                $imagePath = null;
            }
            
            $stmt = $pdo->prepare($sql);
            $success = $stmt->execute([
                trim($_POST['name']),
                trim($_POST['description']),
                floatval($_POST['price']),
                $_POST['currency'] ?? 'USD',
                intval($_POST['category_id']),
                trim($_POST['size']),
                $_POST['size_unit'] ?? 'ml',
                intval($_POST['calories']),
                (isset($_POST['contains_caffeine']) && $_POST['contains_caffeine'] == '1') ? 1 : 0,
                (isset($_POST['is_popular']) && $_POST['is_popular'] == '1') ? 1 : 0,
                $imagePath
            ]);
            
            if (!$success) {
                throw new Exception('Failed to insert menu item');
            }
            
            $menuItemId = $pdo->lastInsertId();
            
            if (!$menuItemId) {
                throw new Exception('Item was inserted but could not get ID');
            }
            
            // Add ingredients
            if (!empty($_POST['ingredients'])) {
                $ingredients = explode(',', $_POST['ingredients']);
                $ingredientSql = "INSERT INTO ingredients (menu_item_id, name) VALUES (?, ?)";
                $ingredientStmt = $pdo->prepare($ingredientSql);
                
                foreach ($ingredients as $ingredient) {
                    if (!empty(trim($ingredient))) {
                        $ingredientStmt->execute([$menuItemId, trim($ingredient)]);
                    }
                }
            }
            
            $message = 'Menu item added successfully! ID: ' . $menuItemId . '. <a href="../menu.php" target="_blank">View Menu</a>';
            $messageType = 'success';
            
            // Debug: Log successful addition
            error_log("Menu item added successfully. ID: " . $menuItemId);
            
            // Redirect to prevent form resubmission
            header('Location: manage_sql.php?success=' . urlencode('Menu item added! ID: ' . $menuItemId));
            exit;
            
        } elseif ($action === 'delete_menu_item') {
            // Delete menu item (cascade will delete ingredients)
            $sql = "DELETE FROM menu_items WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$_POST['item_id']]);
            
            $message = 'Menu item deleted successfully!';
            $messageType = 'success';
            
        } elseif ($action === 'update_setting') {
            // Update cafe settings
            $sql = "INSERT INTO cafe_settings (setting_key, setting_value) VALUES (?, ?)
                    ON DUPLICATE KEY UPDATE setting_value = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$_POST['setting_key'], $_POST['setting_value'], $_POST['setting_value']]);
            
            $message = 'Setting updated successfully!';
            $messageType = 'success';
            
        } elseif ($action === 'add_feature') {
            // Add feature
            $sql = "INSERT INTO features (title, description, icon, display_order) VALUES (?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $_POST['feature_title'],
                $_POST['feature_description'],
                $_POST['feature_icon'],
                $_POST['display_order'] ?? 0
            ]);
            
            $message = 'Feature added successfully!';
            $messageType = 'success';
            
        } elseif ($action === 'delete_feature') {
            $sql = "DELETE FROM features WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$_POST['feature_id']]);
            
            $message = 'Feature deleted successfully!';
            $messageType = 'success';
        }
    } catch (PDOException $e) {
        $message = 'Error: ' . $e->getMessage();
        $messageType = 'error';
        error_log("Admin menu add error: " . $e->getMessage());
    } catch (Exception $e) {
        $message = 'Error: ' . $e->getMessage();
        $messageType = 'error';
        error_log("Admin menu add error: " . $e->getMessage());
    }
}

// Load data from database
try {
    $pdo = getDBConnection();
    
    // Get statistics
    $stats = [
        'menu_items' => fetchOne("SELECT COUNT(*) as count FROM menu_items")['count'] ?? 0,
        'categories' => fetchOne("SELECT COUNT(*) as count FROM categories")['count'] ?? 0,
        'features' => fetchOne("SELECT COUNT(*) as count FROM features WHERE is_active = 1")['count'] ?? 0,
        'offers' => fetchOne("SELECT COUNT(*) as count FROM offers WHERE is_active = 1")['count'] ?? 0,
        'staff' => fetchOne("SELECT COUNT(*) as count FROM staff WHERE is_active = 1")['count'] ?? 0,
        'reviews' => fetchOne("SELECT COUNT(*) as count FROM reviews WHERE is_approved = 1")['count'] ?? 0
    ];
    
    // Get categories for dropdown
    $categories = fetchAll("SELECT id, name FROM categories WHERE is_available = 1 ORDER BY display_order");
    
    if (empty($categories)) {
        $message = 'Warning: No categories found! Items cannot be added without categories. <a href="database/install.php">Run database installation</a>.';
        $messageType = 'error';
    }
} catch (Exception $e) {
    $message = 'Database error: ' . $e->getMessage();
    $messageType = 'error';
    $stats = ['menu_items' => 0, 'categories' => 0, 'features' => 0, 'offers' => 0, 'staff' => 0, 'reviews' => 0];
    $categories = [];
}

// Get current menu items
$menuItems = fetchAll("
    SELECT m.*, c.name as category_name 
    FROM menu_items m 
    LEFT JOIN categories c ON m.category_id = c.id 
    ORDER BY c.display_order, m.name
");

// Get features
$features = fetchAll("SELECT * FROM features WHERE is_active = 1 ORDER BY display_order");

// Get cafe settings
$settings = fetchAll("SELECT setting_key, setting_value FROM cafe_settings");
$settingsMap = [];
foreach ($settings as $setting) {
    $settingsMap[$setting['setting_key']] = $setting['setting_value'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SQL Database Management - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body class="admin-body">
    <nav class="admin-nav">
        <div class="admin-nav-container">
            <div class="admin-logo">
                <h2>☕ Admin Panel</h2>
            </div>
            <div class="admin-nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="manage_menu.php">Manage Menu (XML)</a>
                <a href="manage_data.php">Manage Data (JSON)</a>
                <a href="manage_sql.php" class="active">Manage SQL Database</a>
                <a href="../index.php" target="_blank">View Website</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="admin-container">
        <div class="admin-header">
            <h1>SQL Database Management</h1>
            <p>Manage website data using MySQL database</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>">
                <?php echo $message; ?>
                <?php if ($messageType === 'error' && strpos($message, 'Database') !== false): ?>
                    <br><br>
                    <strong>Check:</strong>
                    <ul style="margin: 10px 0; padding-left: 20px;">
                        <li>Is MySQL service running in XAMPP?</li>
                        <li>Is the database installed? <a href="database/install.php">Run Installation</a></li>
                        <li>Check database credentials in <code>config/database.php</code></li>
                    </ul>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_POST['action']) && $_POST['action'] === 'add_menu_item' && empty($message)): ?>
            <div class="alert alert-error">
                <strong>⚠ No response received.</strong> The form was submitted but no action was processed.
                <br>Check browser console (F12) for JavaScript errors.
            </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">
                <strong>✓ Success!</strong><br>
                <?php echo htmlspecialchars($_GET['success']); ?>
                <br><br>
                <a href="../menu.php" target="_blank" style="color: white; text-decoration: underline; font-weight: bold;">→ View Menu Page</a>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['added'])): ?>
            <div class="alert alert-success">
                <strong>✓ Menu item added!</strong> 
                <a href="../menu.php" target="_blank" style="color: white; text-decoration: underline;">Click here to view the menu</a>
            </div>
        <?php endif; ?>

        <!-- Database Statistics -->
        <div class="admin-section">
            <h2>Database Statistics</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">🍽️</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['menu_items']; ?></h3>
                        <p>Menu Items</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📁</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['categories']; ?></h3>
                        <p>Categories</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">⭐</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['features']; ?></h3>
                        <p>Active Features</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['staff']; ?></h3>
                        <p>Staff Members</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Menu Item -->
        <div class="admin-section">
            <h2>Add Menu Item (SQL Database)</h2>
            <?php if (empty($categories)): ?>
                <div class="alert alert-error">
                    <strong>⚠ Cannot add items:</strong> No categories available. 
                    <a href="../database/install.php">Please run database installation first</a>.
                </div>
            <?php endif; ?>
            <form method="POST" class="admin-form" id="addMenuItemForm" onsubmit="return validateAddMenuForm(event)">
                <input type="hidden" name="action" value="add_menu_item">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Category *</label>
                        <select name="category_id" required>
                            <option value="">-- Select Category --</option>
                            <?php if (!empty($categories)): ?>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <option value="" disabled>No categories available</option>
                            <?php endif; ?>
                        </select>
                        <?php if (empty($categories)): ?>
                            <p style="color: red; font-size: 0.9em; margin-top: 5px;">⚠ No categories found. Please run database installation first.</p>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="name" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="3" required></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Price</label>
                        <input type="number" name="price" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label>Currency</label>
                        <input type="text" name="currency" value="USD">
                    </div>
                    <div class="form-group">
                        <label>Size</label>
                        <input type="text" name="size" required>
                    </div>
                    <div class="form-group">
                        <label>Size Unit</label>
                        <input type="text" name="size_unit" value="ml">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Calories</label>
                        <input type="number" name="calories" required>
                    </div>
                    <div class="form-group">
                        <label>Contains Caffeine</label>
                        <input type="checkbox" name="contains_caffeine" value="1">
                    </div>
                    <div class="form-group">
                        <label>Popular Item</label>
                        <input type="checkbox" name="is_popular" value="1">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Ingredients (comma-separated)</label>
                    <input type="text" name="ingredients" placeholder="Ingredient 1, Ingredient 2, ...">
                </div>
                
                <div class="form-group">
                    <label>Image</label>
                    <select name="image" id="menu-image-select">
                        <option value="">-- No Image --</option>
                        <?php
                        // Get all images from image folder
                        $imageDir = '../image';
                        if (is_dir($imageDir)) {
                            $images = [];
                            $files = scandir($imageDir);
                            foreach ($files as $file) {
                                if ($file !== '.' && $file !== '..') {
                                    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                                    if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
                                        $images[] = $file;
                                    }
                                }
                            }
                            sort($images);
                            foreach ($images as $img) {
                                $imgPath = 'image/' . $img;
                                echo '<option value="' . htmlspecialchars($imgPath) . '">' . htmlspecialchars($img) . '</option>';
                            }
                        }
                        ?>
                    </select>
                    <div id="image-preview" style="margin-top: 10px; display: none;">
                        <img id="preview-img" src="" alt="Preview" style="max-width: 200px; max-height: 150px; border: 1px solid #ddd; border-radius: 5px; padding: 5px;">
                    </div>
                </div>
                
                <button type="submit" class="btn-admin">Add Menu Item</button>
            </form>
        </div>

        <!-- Current Menu Items from Database -->
        <div class="admin-section">
            <h2>Menu Items (from SQL Database)</h2>
            <div class="menu-list">
                <?php
                $currentCategory = '';
                foreach ($menuItems as $item):
                    if ($currentCategory !== $item['category_name']):
                        if ($currentCategory !== '') echo '</div></div>';
                        $currentCategory = $item['category_name'];
                ?>
                    <div class="category-group">
                        <h3 class="category-title"><?php echo htmlspecialchars($currentCategory); ?></h3>
                        <div class="items-grid">
                <?php endif; ?>
                            
                            <div class="menu-item-card">
                                <?php if (!empty($item['image'])): ?>
                                    <div class="menu-item-image" style="margin-bottom: 10px;">
                                        <img src="../<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" style="max-width: 100%; max-height: 150px; border-radius: 5px; object-fit: cover;">
                                    </div>
                                <?php endif; ?>
                                <div class="menu-item-header">
                                    <h4><?php echo htmlspecialchars($item['name']); ?></h4>
                                    <span class="menu-price">$<?php echo number_format($item['price'], 2); ?></span>
                                </div>
                                <p class="menu-item-desc"><?php echo htmlspecialchars($item['description']); ?></p>
                                <div class="menu-item-meta">
                                    <span>Calories: <?php echo $item['calories']; ?></span>
                                    <?php if ($item['is_popular']): ?>
                                        <span class="popular-badge">Popular</span>
                                    <?php endif; ?>
                                </div>
                                <div class="menu-item-actions">
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this item?');">
                                        <input type="hidden" name="action" value="delete_menu_item">
                                        <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                                        <button type="submit" class="btn-delete">Delete</button>
                                    </form>
                                </div>
                            </div>
                            
                <?php endforeach; ?>
                        </div>
                    </div>
            </div>
        </div>

        <!-- Manage Features -->
        <div class="admin-section">
            <h2>Manage Features (SQL)</h2>
            <form method="POST" class="admin-form">
                <input type="hidden" name="action" value="add_feature">
                <div class="form-row">
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" name="feature_title" required>
                    </div>
                    <div class="form-group">
                        <label>Icon</label>
                        <input type="text" name="feature_icon" placeholder="☕" required>
                    </div>
                    <div class="form-group">
                        <label>Display Order</label>
                        <input type="number" name="display_order" value="0">
                    </div>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="feature_description" rows="2" required></textarea>
                </div>
                <button type="submit" class="btn-admin">Add Feature</button>
            </form>
            
            <div style="margin-top: 2rem;">
                <h3>Current Features</h3>
                <div class="features-list">
                    <?php foreach ($features as $feature): ?>
                        <div class="feature-item">
                            <span class="feature-icon"><?php echo htmlspecialchars($feature['icon']); ?></span>
                            <div>
                                <h4><?php echo htmlspecialchars($feature['title']); ?></h4>
                                <p><?php echo htmlspecialchars($feature['description']); ?></p>
                            </div>
                            <form method="POST" style="margin-left: auto;" onsubmit="return confirm('Delete this feature?');">
                                <input type="hidden" name="action" value="delete_feature">
                                <input type="hidden" name="feature_id" value="<?php echo $feature['id']; ?>">
                                <button type="submit" class="btn-delete" style="padding: 0.3rem 0.8rem;">Delete</button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Update Settings -->
        <div class="admin-section">
            <h2>Update Café Settings</h2>
            <form method="POST" class="admin-form">
                <input type="hidden" name="action" value="update_setting">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Setting Key</label>
                        <input type="text" name="setting_key" required>
                    </div>
                    <div class="form-group">
                        <label>Setting Value</label>
                        <input type="text" name="setting_value" required>
                    </div>
                </div>
                
                <button type="submit" class="btn-admin">Update Setting</button>
            </form>
            
            <div style="margin-top: 2rem;">
                <h3>Current Settings</h3>
                <table style="width: 100%; border-collapse: collapse; margin-top: 1rem;">
                    <thead>
                        <tr style="background: #f8f9fa;">
                            <th style="padding: 0.8rem; text-align: left; border-bottom: 2px solid #dee2e6;">Key</th>
                            <th style="padding: 0.8rem; text-align: left; border-bottom: 2px solid #dee2e6;">Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($settingsMap as $key => $value): ?>
                            <tr>
                                <td style="padding: 0.8rem; border-bottom: 1px solid #dee2e6;"><?php echo htmlspecialchars($key); ?></td>
                                <td style="padding: 0.8rem; border-bottom: 1px solid #dee2e6;"><?php echo htmlspecialchars($value); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="../js/admin.js"></script>
    <script>
    // Image preview functionality
    document.addEventListener('DOMContentLoaded', function() {
        const imageSelect = document.getElementById('menu-image-select');
        const imagePreview = document.getElementById('image-preview');
        const previewImg = document.getElementById('preview-img');
        
        if (imageSelect && imagePreview && previewImg) {
            imageSelect.addEventListener('change', function() {
                const selectedImage = this.value;
                if (selectedImage) {
                    previewImg.src = '../' + selectedImage;
                    imagePreview.style.display = 'block';
                } else {
                    imagePreview.style.display = 'none';
                }
            });
        }
    });
    
    // Form validation helper
    function validateAddMenuForm(event) {
        const form = event.target;
        const requiredFields = ['name', 'description', 'price', 'category_id', 'size', 'calories'];
        let isValid = true;
        let missingFields = [];
        
        requiredFields.forEach(field => {
            const input = form.querySelector('[name="' + field + '"]');
            if (input && !input.value.trim()) {
                isValid = false;
                missingFields.push(field);
                input.style.borderColor = '#dc3545';
            } else if (input) {
                input.style.borderColor = '';
            }
        });
        
        if (!isValid) {
            event.preventDefault();
            alert('Please fill in all required fields: ' + missingFields.join(', '));
            return false;
        }
        
        // Check category
        const categorySelect = form.querySelector('[name="category_id"]');
        if (!categorySelect || !categorySelect.value) {
            event.preventDefault();
            alert('Please select a category');
            return false;
        }
        
        return true;
    }
    
    // Debug form submission
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('addMenuItemForm');
        if (form) {
            form.addEventListener('submit', function(e) {
                console.log('Form submitting...');
                console.log('Form data:', new FormData(form));
            });
        }
    });
    </script>
</body>
</html>

