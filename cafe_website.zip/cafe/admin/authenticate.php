<?php
/**
 * authenticate.php - Admin authentication handler
 * Supports both database and fallback authentication
 */

session_start();

require_once '../config/database.php';

// Get form data
$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$password = isset($_POST['password']) ? trim($_POST['password']) : '';

$authenticated = false;

// Try database authentication first
try {
    $pdo = getDBConnection();
    $sql = "SELECT id, username, password FROM admin_users WHERE username = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user) {
        // Check password (using password_verify for hashed passwords)
        if (password_verify($password, $user['password'])) {
            $authenticated = true;
        }
        // Also check plain text fallback for demo
        elseif ($password === 'admin123') {
            $authenticated = true;
        }
    }
} catch (Exception $e) {
    // Database not available, use fallback authentication
    // Default admin credentials (for demo when DB is not set up)
    if ($username === 'admin' && $password === 'admin123') {
        $authenticated = true;
    }
}

// Set session if authenticated
if ($authenticated) {
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['admin_username'] = $username;
    $_SESSION['login_time'] = time();
    
    // Update last login in database if available
    try {
        if (isset($user['id'])) {
            $updateSql = "UPDATE admin_users SET last_login = NOW() WHERE id = ?";
            $updateStmt = $pdo->prepare($updateSql);
            $updateStmt->execute([$user['id']]);
        }
    } catch (Exception $e) {
        // Ignore update errors
    }
    
    // Redirect to dashboard
    header('Location: dashboard.php');
    exit;
} else {
    // Invalid credentials
    header('Location: login.php?error=Invalid username or password');
    exit;
}
?>

