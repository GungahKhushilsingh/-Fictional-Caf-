<?php
/**
 * fix_menu_items.php - Fix script to ensure menu items are visible
 * Run this once to fix existing items that might not be showing
 */

require_once 'auth_check.php';
require_once '../config/database.php';

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fix'])) {
    try {
        $pdo = getDBConnection();
        
        // Fix 1: Ensure all items have is_available = 1
        $fixed1 = executeQuery("UPDATE menu_items SET is_available = 1 WHERE is_available = 0");
        
        // Fix 2: Ensure all categories have is_available = 1
        $fixed2 = executeQuery("UPDATE categories SET is_available = 1 WHERE is_available = 0");
        
        // Fix 3: Update items with NULL is_available to 1
        $fixed3 = executeQuery("UPDATE menu_items SET is_available = 1 WHERE is_available IS NULL");
        
        $message = 'Menu items fixed successfully! All items and categories are now set to available.';
        $messageType = 'success';
        
    } catch (Exception $e) {
        $message = 'Error: ' . $e->getMessage();
        $messageType = 'error';
    }
}

// Check current status
try {
    $pdo = getDBConnection();
    
    $unavailableItems = fetchOne("SELECT COUNT(*) as count FROM menu_items WHERE is_available = 0 OR is_available IS NULL");
    $unavailableCategories = fetchOne("SELECT COUNT(*) as count FROM categories WHERE is_available = 0");
    
} catch (Exception $e) {
    $unavailableItems = ['count' => 0];
    $unavailableCategories = ['count' => 0];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix Menu Items - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body class="admin-body">
    <nav class="admin-nav">
        <div class="admin-nav-container">
            <div class="admin-logo">
                <h2>☕ Admin Panel</h2>
            </div>
            <div class="admin-nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="manage_sql.php">Manage SQL Database</a>
                <a href="../menu.php" target="_blank">View Menu</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="admin-container">
        <div class="admin-header">
            <h1>Fix Menu Items</h1>
            <p>Ensure all menu items are visible on the website</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <div class="admin-section">
            <h2>Current Status</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-info">
                        <h3><?php echo $unavailableItems['count']; ?></h3>
                        <p>Unavailable Menu Items</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-info">
                        <h3><?php echo $unavailableCategories['count']; ?></h3>
                        <p>Unavailable Categories</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="admin-section">
            <h2>Fix Actions</h2>
            <p>This will:</p>
            <ul>
                <li>Set all menu items to <code>is_available = 1</code></li>
                <li>Set all categories to <code>is_available = 1</code></li>
                <li>Ensure all items can be displayed on the website</li>
            </ul>
            
            <form method="POST" style="margin-top: 2rem;">
                <button type="submit" name="fix" value="1" class="btn-admin">Fix All Menu Items</button>
            </form>
        </div>

        <div class="admin-section">
            <h2>Debug Tools</h2>
            <p>Use these tools to diagnose issues:</p>
            <ul>
                <li><a href="../api/debug_menu.php" target="_blank">Menu Debug Tool</a> - See what's in the database vs what the API returns</li>
                <li><a href="../api/get_menu_sql.php" target="_blank">View API Response</a> - See the raw JSON from the API</li>
                <li><a href="../test_connection.php">Test Database Connection</a> - Verify database is working</li>
            </ul>
        </div>
    </div>
</body>
</html>

