<?php
/**
 * manage_contact.php - Admin page to view and manage contact messages
 */

require_once 'auth_check.php';
require_once '../config/database.php';

$message = '';
$messageType = '';

// Handle form submissions (mark as read, delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    try {
        $pdo = getDBConnection();
        $action = $_POST['action'];
        
        if ($action === 'mark_read') {
            $messageId = intval($_POST['message_id']);
            $isRead = intval($_POST['is_read']);
            
            $sql = "UPDATE contact_messages SET is_read = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$isRead, $messageId]);
            
            $message = $isRead ? 'Message marked as read!' : 'Message marked as unread!';
            $messageType = 'success';
            
        } elseif ($action === 'delete_message') {
            $messageId = intval($_POST['message_id']);
            
            $sql = "DELETE FROM contact_messages WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$messageId]);
            
            $message = 'Message deleted successfully!';
            $messageType = 'success';
        }
    } catch (Exception $e) {
        $message = 'Error: ' . $e->getMessage();
        $messageType = 'error';
    }
}

// Load contact messages from database
$tableExists = false;
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

try {
    $pdo = getDBConnection();
    
    // Check if table exists
    try {
        $checkTable = $pdo->query("SHOW TABLES LIKE 'contact_messages'");
        $tableExists = $checkTable->rowCount() > 0;
    } catch (Exception $e) {
        $tableExists = false;
    }
    
    if ($tableExists) {
        // Load from database
        if ($filter === 'unread') {
            $sql = "SELECT * FROM contact_messages WHERE is_read = 0 ORDER BY created_at DESC";
            $contactMessages = fetchAll($sql);
        } elseif ($filter === 'read') {
            $sql = "SELECT * FROM contact_messages WHERE is_read = 1 ORDER BY created_at DESC";
            $contactMessages = fetchAll($sql);
        } else {
            $sql = "SELECT * FROM contact_messages ORDER BY created_at DESC";
            $contactMessages = fetchAll($sql);
        }
        
        if ($contactMessages === false) {
            $contactMessages = [];
        }
        
        // Get statistics
        try {
            $totalResult = fetchOne("SELECT COUNT(*) as count FROM contact_messages");
            $unreadResult = fetchOne("SELECT COUNT(*) as count FROM contact_messages WHERE is_read = 0");
            $readResult = fetchOne("SELECT COUNT(*) as count FROM contact_messages WHERE is_read = 1");
            
            $stats = [
                'total' => $totalResult['count'] ?? 0,
                'unread' => $unreadResult['count'] ?? 0,
                'read' => $readResult['count'] ?? 0
            ];
        } catch (Exception $e) {
            $stats = ['total' => 0, 'unread' => 0, 'read' => 0];
        }
        
        // Also try to load from JSON fallback for comparison
        $jsonMessages = [];
        $jsonFile = '../data/data.json';
        if (file_exists($jsonFile)) {
            $jsonData = file_get_contents($jsonFile);
            $jsonContent = json_decode($jsonData, true);
            if (isset($jsonContent['messages']) && is_array($jsonContent['messages'])) {
                $jsonMessages = $jsonContent['messages'];
            }
        }
        
    } else {
        // Table doesn't exist, try JSON fallback
        $contactMessages = [];
        $stats = ['total' => 0, 'unread' => 0, 'read' => 0];
        
        $jsonFile = '../data/data.json';
        if (file_exists($jsonFile)) {
            $jsonData = file_get_contents($jsonFile);
            $jsonContent = json_decode($jsonData, true);
            if (isset($jsonContent['messages']) && is_array($jsonContent['messages'])) {
                $contactMessages = $jsonContent['messages'];
                $stats['total'] = count($contactMessages);
                $stats['unread'] = count(array_filter($contactMessages, function($msg) {
                    return !isset($msg['read']) || !$msg['read'];
                }));
                $stats['read'] = $stats['total'] - $stats['unread'];
            }
        }
        
        $jsonMessages = $contactMessages;
    }
    
} catch (Exception $e) {
    $contactMessages = [];
    $stats = ['total' => 0, 'unread' => 0, 'read' => 0];
    $jsonMessages = [];
    $message = 'Error loading contact messages: ' . $e->getMessage();
    $messageType = 'error';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Contact Messages - Admin Panel</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .message-read {
            opacity: 0.7;
        }
        .message-unread {
            background: #f0f8ff;
            border-left: 4px solid #0066cc;
        }
        
        .filter-tabs {
            display: flex;
            gap: 10px;
            margin: 20px 0;
            flex-wrap: wrap;
        }
        .filter-tab {
            padding: 8px 16px;
            background: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s;
        }
        .filter-tab:hover {
            background: #e9e9e9;
        }
        .filter-tab.active {
            background: #6f4e37;
            color: white;
            border-color: #6f4e37;
        }
        
        .message-card {
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 15px;
            transition: all 0.3s;
        }
        .message-card:hover {
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }
        .message-info h3 {
            margin: 0 0 5px 0;
            color: #2c3e50;
            font-size: 1.1em;
        }
        .message-info p {
            margin: 3px 0;
            color: #666;
            font-size: 0.9em;
        }
        .message-body {
            color: #333;
            line-height: 1.6;
            margin: 15px 0;
            padding: 15px;
            background: #f9f9f9;
            border-radius: 5px;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .message-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .btn-small {
            padding: 6px 14px;
            font-size: 0.85em;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn-mark-read { background: #28a745; color: white; }
        .btn-mark-unread { background: #ffc107; color: #333; }
        .btn-delete { background: #dc3545; color: white; }
        .btn-small:hover { opacity: 0.9; }
        
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.75em;
            font-weight: 600;
            margin-left: 10px;
        }
        .badge-unread {
            background: #0066cc;
            color: white;
        }
        .badge-read {
            background: #28a745;
            color: white;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #999;
        }
    </style>
</head>
<body class="admin-body">
    <!-- Admin Navigation -->
    <nav class="admin-nav">
        <div class="admin-nav-container">
            <div class="admin-logo">
                <h2>☕ Admin Panel</h2>
            </div>
            <div class="admin-nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="manage_sql.php">Manage Menu</a>
                <a href="manage_data.php">Manage Data</a>
                <a href="manage_reservations.php">Reservations</a>
                <a href="manage_contact.php" class="active">Contact Messages</a>
                <a href="../index.php" target="_blank">View Website</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="admin-container">
        <div class="admin-header">
            <h1>Contact Messages</h1>
            <p>View and manage customer contact form submissions</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="admin-section">
            <h2>Message Statistics</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">📧</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['total']; ?></h3>
                        <p>Total Messages</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📬</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['unread']; ?></h3>
                        <p>Unread</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">✓</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['read']; ?></h3>
                        <p>Read</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter Tabs -->
        <div class="admin-section">
            <h2>All Messages</h2>
            <div class="filter-tabs">
                <a href="?filter=all" class="filter-tab <?php echo $filter === 'all' ? 'active' : ''; ?>">All</a>
                <a href="?filter=unread" class="filter-tab <?php echo $filter === 'unread' ? 'active' : ''; ?>">Unread</a>
                <a href="?filter=read" class="filter-tab <?php echo $filter === 'read' ? 'active' : ''; ?>">Read</a>
            </div>

            <?php if (empty($contactMessages)): ?>
                <div class="empty-state">
                    <p style="font-size: 1.2em; margin-bottom: 10px;">📭 No contact messages found</p>
                    <p>When customers submit contact forms, they will appear here.</p>
                </div>
            <?php else: ?>
                <?php foreach ($contactMessages as $msg): ?>
                    <?php
                    $isRead = isset($msg['is_read']) ? $msg['is_read'] : (isset($msg['read']) ? $msg['read'] : false);
                    $messageId = isset($msg['id']) ? $msg['id'] : 0;
                    $messageDate = isset($msg['created_at']) ? $msg['created_at'] : (isset($msg['date']) ? $msg['date'] : '');
                    $email = isset($msg['email']) ? $msg['email'] : '';
                    $name = isset($msg['name']) ? $msg['name'] : '';
                    $messageText = isset($msg['message']) ? $msg['message'] : '';
                    ?>
                    <div class="message-card <?php echo $isRead ? 'message-read' : 'message-unread'; ?>">
                        <div class="message-header">
                            <div class="message-info">
                                <h3>
                                    <?php echo htmlspecialchars($name); ?>
                                    <span class="badge <?php echo $isRead ? 'badge-read' : 'badge-unread'; ?>">
                                        <?php echo $isRead ? 'Read' : 'Unread'; ?>
                                    </span>
                                </h3>
                                <p><strong>Email:</strong> <a href="mailto:<?php echo htmlspecialchars($email); ?>"><?php echo htmlspecialchars($email); ?></a></p>
                                <p><strong>Date:</strong> <?php echo $messageDate ? date('M d, Y g:i A', strtotime($messageDate)) : 'Unknown'; ?></p>
                                <?php if ($messageId): ?>
                                    <p style="font-size: 0.85em; color: #999;">ID: <?php echo $messageId; ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="message-body">
                            <?php echo nl2br(htmlspecialchars($messageText)); ?>
                        </div>
                        <?php if ($tableExists && $messageId): ?>
                            <div class="message-actions">
                                <?php if ($isRead): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="mark_read">
                                        <input type="hidden" name="message_id" value="<?php echo $messageId; ?>">
                                        <input type="hidden" name="is_read" value="0">
                                        <button type="submit" class="btn-small btn-mark-unread">Mark as Unread</button>
                                    </form>
                                <?php else: ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="mark_read">
                                        <input type="hidden" name="message_id" value="<?php echo $messageId; ?>">
                                        <input type="hidden" name="is_read" value="1">
                                        <button type="submit" class="btn-small btn-mark-read">Mark as Read</button>
                                    </form>
                                <?php endif; ?>
                                
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this message? This cannot be undone.');">
                                    <input type="hidden" name="action" value="delete_message">
                                    <input type="hidden" name="message_id" value="<?php echo $messageId; ?>">
                                    <button type="submit" class="btn-small btn-delete">Delete</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <script src="../js/admin.js"></script>
</body>
</html>

