<?php
/**
 * dashboard.php - Admin dashboard
 * Main admin interface for managing the website
 */
require_once 'auth_check.php';
require_once '../config/database.php';

// Try to get statistics from database, fallback to XML/JSON
$menuCount = 0;
$staffCount = 0;
$rating = 'N/A';
$offersCount = 0;

try {
    $pdo = getDBConnection();
    $menuCount = fetchOne("SELECT COUNT(*) as count FROM menu_items")['count'];
    $staffCount = fetchOne("SELECT COUNT(*) as count FROM staff WHERE is_active = 1")['count'];
    $offersCount = fetchOne("SELECT COUNT(*) as count FROM offers WHERE is_active = 1")['count'];
    
    // Get average rating
    $ratingResult = fetchOne("SELECT AVG(rating) as avg FROM reviews WHERE is_approved = 1");
    if ($ratingResult && $ratingResult['avg']) {
        $rating = number_format($ratingResult['avg'], 2);
    }
} catch (Exception $e) {
    // Fallback to XML/JSON
    $jsonFile = '../data/data.json';
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $data = json_decode($jsonData, true);
        $staffCount = isset($data['totalStaff']) ? $data['totalStaff'] : (isset($data['staff']) ? count($data['staff']) : 0);
        $offersCount = isset($data['totalOffers']) ? $data['totalOffers'] : (isset($data['offers']) ? count($data['offers']) : 0);
        $rating = isset($data['averageRating']) ? $data['averageRating'] : 'N/A';
    }
    
    $xmlFile = '../data/menu.xml';
    if (file_exists($xmlFile)) {
        $xml = simplexml_load_file($xmlFile);
        $menuCount = count($xml->xpath('//item'));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Café Delight</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body class="admin-body">
    <!-- Admin Navigation -->
    <nav class="admin-nav">
        <div class="admin-nav-container">
            <div class="admin-logo">
                <h2>☕ Admin Panel</h2>
            </div>
            <div class="admin-nav-links">
                <a href="dashboard.php" class="active">Dashboard</a>
                <a href="manage_sql.php">Manage Menu</a>
                <a href="manage_data.php">Manage Data</a>
                <a href="manage_reservations.php">Reservations</a>
                <a href="manage_contact.php">Messages</a>
                <a href="../index.php" target="_blank">View Website</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Dashboard Content -->
    <div class="admin-container">
        <div class="admin-header">
            <h1>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?>!</h1>
            <p>Manage your café website content and settings</p>
        </div>

        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">🍽️</div>
                <div class="stat-info">
                    <h3><?php echo $menuCount; ?></h3>
                    <p>Menu Items</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-info">
                    <h3><?php echo $staffCount; ?></h3>
                    <p>Staff Members</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">⭐</div>
                <div class="stat-info">
                    <h3><?php echo $rating; ?></h3>
                    <p>Average Rating</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">🎁</div>
                <div class="stat-info">
                    <h3><?php echo $offersCount; ?></h3>
                    <p>Active Offers</p>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="admin-section">
            <h2>Quick Actions</h2>
            <div class="action-grid">
                <a href="manage_sql.php" class="action-card" style="border: 2px solid #d4a574; box-shadow: 0 4px 8px rgba(212, 165, 116, 0.3);">
                    <div class="action-icon">🗄️</div>
                    <h3>Manage Menu (SQL) ⭐</h3>
                    <p><strong>Primary Method</strong> - Add, edit, or remove menu items from database</p>
                </a>
                
                <a href="manage_data.php" class="action-card">
                    <div class="action-icon">⚙️</div>
                    <h3>Manage Data (JSON)</h3>
                    <p>Update features, offers, staff, and contact info</p>
                </a>
                
                <a href="manage_reservations.php" class="action-card">
                    <div class="action-icon">📅</div>
                    <h3>View Reservations</h3>
                    <p>Manage customer table reservations</p>
                </a>
                
                <a href="manage_contact.php" class="action-card">
                    <div class="action-icon">📧</div>
                    <h3>Contact Messages</h3>
                    <p>View and manage customer contact form submissions</p>
                </a>
                
                <a href="manage_menu.php" class="action-card" style="opacity: 0.7; border: 1px dashed #888;">
                    <div class="action-icon">📝</div>
                    <h3>Edit Menu (XML) <small style="font-size: 0.8em; color: #888;">Fallback Only</small></h3>
                    <p style="font-size: 0.85em; color: #666;">Legacy XML editor (use SQL instead)</p>
                </a>
                
                <a href="../menu.php" target="_blank" class="action-card">
                    <div class="action-icon">👁️</div>
                    <h3>Preview Menu</h3>
                    <p>View how the menu appears to customers</p>
                </a>
                
                <a href="../index.php" target="_blank" class="action-card">
                    <div class="action-icon">🌐</div>
                    <h3>View Website</h3>
                    <p>See the public-facing website</p>
                </a>
            </div>
        </div>
    </div>

    <script src="../js/admin.js"></script>
</body>
</html>

