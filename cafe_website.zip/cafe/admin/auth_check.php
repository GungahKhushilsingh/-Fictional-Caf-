<?php
/**
 * auth_check.php - Check if admin is logged in
 * Include this file at the top of admin pages that require authentication
 */

session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Optional: Check session timeout (15 minutes)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 900)) {
    session_destroy();
    header('Location: login.php?error=Session expired. Please login again.');
    exit;
}

// Update last activity time
$_SESSION['login_time'] = time();
?>

