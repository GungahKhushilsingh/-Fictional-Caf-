<?php
/**
 * manage_data.php - Admin page to manage JSON data
 * Demonstrates PHP JSON manipulation
 */
require_once 'auth_check.php';

$jsonFile = '../data/data.json';
$message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jsonData = file_get_contents($jsonFile);
    $data = json_decode($jsonData, true);
    
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'update_contact') {
            // Update contact information
            $data['cafeInfo']['contact']['phone'] = $_POST['phone'];
            $data['cafeInfo']['contact']['email'] = $_POST['email'];
            $data['cafeInfo']['location']['address'] = $_POST['address'];
            $data['cafeInfo']['location']['city'] = $_POST['city'];
            $data['cafeInfo']['location']['state'] = $_POST['state'];
            $data['cafeInfo']['location']['zipCode'] = $_POST['zipCode'];
            $message = 'Contact information updated successfully!';
        } elseif ($action === 'add_feature') {
            // Add new feature
            if (!isset($data['features'])) {
                $data['features'] = [];
            }
            $newFeature = [
                'id' => time(),
                'title' => $_POST['feature_title'],
                'description' => $_POST['feature_description'],
                'icon' => $_POST['feature_icon']
            ];
            $data['features'][] = $newFeature;
            $message = 'Feature added successfully!';
        } elseif ($action === 'add_offer') {
            // Add new offer
            if (!isset($data['offers'])) {
                $data['offers'] = [];
            }
            $newOffer = [
                'id' => time(),
                'title' => $_POST['offer_title'],
                'description' => $_POST['offer_description'],
                'validUntil' => $_POST['offer_valid_until'],
                'category' => $_POST['offer_category']
            ];
            $data['offers'][] = $newOffer;
            $message = 'Offer added successfully!';
        }
        
        // Save updated JSON
        file_put_contents($jsonFile, json_encode($data, JSON_PRETTY_PRINT));
    }
}

// Load current data
$jsonData = file_get_contents($jsonFile);
$data = json_decode($jsonData, true);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Data - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body class="admin-body">
    <nav class="admin-nav">
        <div class="admin-nav-container">
            <div class="admin-logo">
                <h2>☕ Admin Panel</h2>
            </div>
            <div class="admin-nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="manage_menu.php">Manage Menu</a>
                <a href="manage_data.php" class="active">Manage Data</a>
                <a href="../index.php" target="_blank">View Website</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="admin-container">
        <div class="admin-header">
            <h1>Manage Website Data</h1>
            <p>Update contact information, features, and offers</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <!-- Contact Information -->
        <div class="admin-section">
            <h2>Contact Information</h2>
            <form method="POST" class="admin-form">
                <input type="hidden" name="action" value="update_contact">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" value="<?php echo htmlspecialchars($data['cafeInfo']['contact']['phone']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($data['cafeInfo']['contact']['email']); ?>" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Address</label>
                        <input type="text" name="address" value="<?php echo htmlspecialchars($data['cafeInfo']['location']['address']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" name="city" value="<?php echo htmlspecialchars($data['cafeInfo']['location']['city']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>State</label>
                        <input type="text" name="state" value="<?php echo htmlspecialchars($data['cafeInfo']['location']['state']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Zip Code</label>
                        <input type="text" name="zipCode" value="<?php echo htmlspecialchars($data['cafeInfo']['location']['zipCode']); ?>" required>
                    </div>
                </div>
                
                <button type="submit" class="btn-admin">Update Contact Info</button>
            </form>
        </div>

        <!-- Add Feature -->
        <div class="admin-section">
            <h2>Add New Feature</h2>
            <form method="POST" class="admin-form">
                <input type="hidden" name="action" value="add_feature">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" name="feature_title" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Icon (emoji)</label>
                        <input type="text" name="feature_icon" placeholder="☕" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="feature_description" rows="2" required></textarea>
                </div>
                
                <button type="submit" class="btn-admin">Add Feature</button>
            </form>
        </div>

        <!-- Current Features -->
        <div class="admin-section">
            <h2>Current Features</h2>
            <div class="features-list">
                <?php foreach ($data['features'] as $feature): ?>
                    <div class="feature-item">
                        <span class="feature-icon"><?php echo htmlspecialchars($feature['icon']); ?></span>
                        <div>
                            <h4><?php echo htmlspecialchars($feature['title']); ?></h4>
                            <p><?php echo htmlspecialchars($feature['description']); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Add Offer -->
        <div class="admin-section">
            <h2>Add New Offer</h2>
            <form method="POST" class="admin-form">
                <input type="hidden" name="action" value="add_offer">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" name="offer_title" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Category</label>
                        <select name="offer_category" required>
                            <option value="all">All</option>
                            <option value="beverages">Beverages</option>
                            <option value="food">Food</option>
                            <option value="desserts">Desserts</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Valid Until</label>
                        <input type="date" name="offer_valid_until" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="offer_description" rows="2" required></textarea>
                </div>
                
                <button type="submit" class="btn-admin">Add Offer</button>
            </form>
        </div>

        <!-- Current Offers -->
        <div class="admin-section">
            <h2>Current Offers</h2>
            <div class="offers-list">
                <?php foreach ($data['offers'] as $offer): ?>
                    <div class="offer-item">
                        <h4><?php echo htmlspecialchars($offer['title']); ?></h4>
                        <p><?php echo htmlspecialchars($offer['description']); ?></p>
                        <span class="offer-meta">Valid until: <?php echo htmlspecialchars($offer['validUntil']); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script src="../js/admin.js"></script>
</body>
</html>

