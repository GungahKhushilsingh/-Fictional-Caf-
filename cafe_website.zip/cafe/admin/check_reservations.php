<?php
/**
 * check_reservations.php - Debug script to check reservations
 */

require_once '../config/database.php';

header('Content-Type: text/html; charset=utf-8');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Check Reservations</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
        .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #6f4e37; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Reservations Debug Check</h1>
        
        <?php
        try {
            $pdo = getDBConnection();
            echo "<div class='success'>✓ Database connected</div>";
            
            // Check if table exists
            $checkTable = $pdo->query("SHOW TABLES LIKE 'reservations'");
            $tableExists = $checkTable->rowCount() > 0;
            
            if ($tableExists) {
                echo "<div class='success'>✓ Reservations table exists</div>";
                
                // Count reservations
                $count = fetchOne("SELECT COUNT(*) as count FROM reservations");
                echo "<div class='info'><strong>Total Reservations in Database:</strong> " . $count['count'] . "</div>";
                
                // Get all reservations
                $reservations = fetchAll("SELECT * FROM reservations ORDER BY created_at DESC");
                
                if (count($reservations) > 0) {
                    echo "<h2>All Reservations:</h2>";
                    echo "<table>";
                    echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Date</th><th>Time</th><th>Guests</th><th>Status</th><th>Created</th></tr>";
                    foreach ($reservations as $res) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($res['id']) . "</td>";
                        echo "<td>" . htmlspecialchars($res['name']) . "</td>";
                        echo "<td>" . htmlspecialchars($res['email']) . "</td>";
                        echo "<td>" . htmlspecialchars($res['phone']) . "</td>";
                        echo "<td>" . htmlspecialchars($res['reservation_date']) . "</td>";
                        echo "<td>" . htmlspecialchars($res['reservation_time']) . "</td>";
                        echo "<td>" . htmlspecialchars($res['guests']) . "</td>";
                        echo "<td>" . htmlspecialchars($res['status']) . "</td>";
                        echo "<td>" . htmlspecialchars($res['created_at']) . "</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "<div class='info'>No reservations found in database</div>";
                }
                
                // Check JSON fallback
                $jsonFile = '../data/reservations.json';
                if (file_exists($jsonFile)) {
                    $jsonData = file_get_contents($jsonFile);
                    $jsonReservations = json_decode($jsonData, true);
                    $jsonCount = is_array($jsonReservations) ? count($jsonReservations) : 0;
                    echo "<div class='info'><strong>Reservations in JSON file:</strong> $jsonCount</div>";
                }
                
            } else {
                echo "<div class='error'>✗ Reservations table does NOT exist</div>";
                echo "<div class='info'>The table should be created automatically when a reservation is submitted.</div>";
            }
            
            // Check recent error log entries
            echo "<h2>Recent Activity:</h2>";
            $logFile = ini_get('error_log');
            if ($logFile && file_exists($logFile)) {
                $lines = file($logFile);
                $reservationLogs = array_filter($lines, function($line) {
                    return stripos($line, 'reservation') !== false;
                });
                $recent = array_slice(array_reverse($reservationLogs), 0, 10);
                if (!empty($recent)) {
                    echo "<div class='info'>Recent reservation-related log entries:</div>";
                    echo "<pre style='background: #f5f5f5; padding: 15px; border-radius: 5px; overflow-x: auto;'>";
                    foreach ($recent as $log) {
                        echo htmlspecialchars($log);
                    }
                    echo "</pre>";
                } else {
                    echo "<div class='info'>No recent reservation log entries found</div>";
                }
            } else {
                echo "<div class='info'>Error log file not found or not configured</div>";
            }
            
        } catch (Exception $e) {
            echo "<div class='error'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
        ?>
        
        <hr>
        <h2>Test Actions</h2>
        <p>
            <a href="manage_reservations.php" style="display: inline-block; padding: 10px 20px; background: #6f4e37; color: white; text-decoration: none; border-radius: 5px;">Go to Reservations Admin</a>
            <a href="../test_reservation_submit.php" target="_blank" style="display: inline-block; padding: 10px 20px; background: #6f4e37; color: white; text-decoration: none; border-radius: 5px; margin-left: 10px;">Test Form Submission</a>
        </p>
    </div>
</body>
</html>

