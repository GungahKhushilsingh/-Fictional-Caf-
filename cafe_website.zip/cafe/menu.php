<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu - Café Delight</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/menu-cards.css">
</head>
<body>
    <!-- Navigation Menu -->
    <nav class="navbar">
        <div class="container">
            <div class="logo">
                <h1>☕ Café Delight</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="menu.php" class="active">Menu</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="reservation.php">Reservation</a></li>
                <li><a href="admin/login.php">Admin</a></li>
            </ul>
        </div>
    </nav>

    <style>
        /* Hover animations for filters and menu cards - Mocha Noir */
        .menu-filters .filter-btn{transition: transform .25s ease, box-shadow .3s ease, background .3s ease, color .3s ease;}
        .menu-filters .filter-btn:hover{transform: translateY(-3px) scale(1.04); box-shadow: 0 10px 28px rgba(212,175,55,0.3); background: #D4AF37; color:#1A1A1A;}
        #menuContainer .menu-item{transition: transform .3s ease, box-shadow .35s ease, backdrop-filter .3s ease, border-color .3s ease;}
        #menuContainer .menu-item:hover{transform: translateY(-8px) scale(1.03); box-shadow: 0 18px 44px rgba(212,175,55,0.4); backdrop-filter: blur(18px); border-color: #D4AF37;}        
        #menuContainer .menu-item h3{transition: letter-spacing .25s ease, color .25s ease;}
        #menuContainer .menu-item:hover h3{letter-spacing: .6px; color: #D4AF37;}        

        /* Extra hover effects for the grid items */
        #menuContainer .menu-item .menu-price{transition: transform .25s ease, color .25s ease, text-shadow .25s ease;}
        #menuContainer .menu-item:hover .menu-price{transform: scale(1.06); color: #D4AF37; text-shadow: 0 6px 18px rgba(212,175,55,.45);} 
        #menuContainer .menu-item .menu-description{transition: filter .25s ease, opacity .25s ease; opacity: .9;}
        #menuContainer .menu-item:hover .menu-description{filter: brightness(1.08); opacity: 1;}

        /* Card shine sweep */
        #menuContainer .menu-item{ position: relative; overflow: hidden; }
        #menuContainer .menu-item::after{
            content: '';
            position: absolute; inset: 0; left: -150%; width: 120%; height: 100%;
            background: linear-gradient(75deg, rgba(212,175,55,0) 0%, rgba(212,175,55,0.15) 50%, rgba(212,175,55,0) 100%);
            transform: skewX(-20deg) translateX(0); transition: transform 700ms ease;
            pointer-events: none;
        }
        #menuContainer .menu-item:hover::after{ transform: skewX(-20deg) translateX(240%); }

        /* Banner Section with Background Image */
        .banner-section {
            background-image: url('image/backgroundmenu.jpg');
            background-position: center 120%;
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-color: #000000;
            padding: 4rem 0;
            position: relative;
            min-height: 50vh;
        }

        /* Premium Limited Availability Banner - Mocha Noir */
        #limitedBanner {
            background: rgba(0, 0, 0, 0.85);
            color: #FAFAFA;
            padding: 1.25rem 2rem;
            border-radius: 16px;
            text-align: center;
            border: 2px solid rgba(212, 175, 55, 0.8);
            box-shadow: 0 8px 32px rgba(212, 175, 55, 0.4),
                        0 4px 16px rgba(62, 44, 35, 0.2),
                        0 0 0 1px rgba(212, 175, 55, 0.3) inset;
            position: relative;
            overflow: hidden;
            font-family: 'Montserrat', 'Segoe UI', sans-serif;
            font-size: 1.05rem;
            font-weight: 600;
            letter-spacing: 0.5px;
            animation: bannerGlow 3s ease-in-out infinite;
            max-width: 900px;
            margin: 0 auto;
        }
        
        #limitedBanner > * {
            position: relative;
            z-index: 1;
        }

        /* Shimmer effect overlay */
        #limitedBanner::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                45deg,
                transparent 30%,
                rgba(212, 175, 55, 0.2) 50%,
                transparent 70%
            );
            transform: translateX(-100%) translateY(-100%) rotate(45deg);
            animation: shimmer 4s infinite;
            pointer-events: none;
            z-index: 1;
        }

        /* Glow animation */
        @keyframes bannerGlow {
            0%, 100% {
                box-shadow: 0 8px 32px rgba(212, 175, 55, 0.4),
                            0 4px 16px rgba(62, 44, 35, 0.2);
            }
            50% {
                box-shadow: 0 12px 40px rgba(212, 175, 55, 0.6),
                            0 6px 20px rgba(62, 44, 35, 0.3),
                            0 0 20px rgba(212, 175, 55, 0.3);
            }
        }

        /* Shimmer sweep animation */
        @keyframes shimmer {
            0% {
                transform: translateX(-100%) translateY(-100%) rotate(45deg);
            }
            100% {
                transform: translateX(100%) translateY(100%) rotate(45deg);
            }
        }

        /* Countdown styling */
        #limitedBanner strong {
            font-weight: 700;
            letter-spacing: 1px;
        }

        #limitedBanner #countdown {
            font-family: 'Montserrat', monospace;
            font-weight: 700;
            font-size: 1.15rem;
            letter-spacing: 2px;
            color: #D4AF37;
            text-shadow: 0 2px 8px rgba(0, 0, 0, 0.6), 0 0 10px rgba(212, 175, 55, 0.5);
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            #limitedBanner {
                padding: 1rem 1.5rem;
                font-size: 0.95rem;
            }
            #limitedBanner #countdown {
                font-size: 1rem;
                letter-spacing: 1.5px;
            }
        }
    </style>

    <!-- Limited availability banner -->
    <section class="banner-section">
        <div class="container">
            <div id="limitedBanner">
                Limited availability today – ends in <strong><span id="countdown">--:--:--</span></strong>
            </div>
        </div>
    </section>

    <!-- Menu Section -->
    <section class="menu-section">
        <div class="container">
            <div style="background: rgba(62, 44, 35, 0.4); backdrop-filter: blur(15px); -webkit-backdrop-filter: blur(15px); border: 1px solid rgba(212,175,55,0.3); border-radius: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.4); padding: 1.5rem;">
            <h2 style="color: #D4AF37; letter-spacing: 0.5px;">Our Menu</h2>
            <p class="subtitle" style="color: rgba(250,250,250,0.8);">Discover our delicious selection of beverages and treats</p>
            
            <!-- Filter buttons -->
            <div class="menu-filters" style="background: rgba(62, 44, 35, 0.4); backdrop-filter: blur(15px); -webkit-backdrop-filter: blur(15px); border: 1px solid rgba(212,175,55,0.3); border-radius: 16px; padding: 8px;">
                <button class="filter-btn active" onclick="filterMenu('all')">All Items</button>
                <button class="filter-btn" onclick="filterMenu('beverages')">Beverages</button>
                <button class="filter-btn" onclick="filterMenu('food')">Food</button>
                <button class="filter-btn" onclick="filterMenu('desserts')">Desserts</button>
            </div>

            <!-- Menu items will be loaded via AJAX -->
            <div id="menuContainer" class="menu-grid">
                <p class="loading">Loading menu...</p>
            </div>
            <div id="menuStatus" style="text-align: center; margin-top: 1rem; color: rgba(250,250,250,0.7); font-size: 0.9rem;"></div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Café Delight. All rights reserved.</p>
            <p style="margin-top: 1rem; opacity: 0.8; font-size: 0.9rem;">
                <a href="admin/login.php" style="color: #D4AF37; text-decoration: none;">Admin Login</a>
            </p>
        </div>
    </footer>

    <!-- JavaScript for AJAX XML loading and DOM manipulation -->
    <script src="js/menu.js?v=<?php echo time(); ?>"></script>
</body>
</html>

