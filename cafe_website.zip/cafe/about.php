<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Café Delight</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Navigation Menu -->
    <nav class="navbar">
        <div class="container">
            <div class="logo">
                <h1>☕ Café Delight</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="about.php" class="active">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="reservation.php">Reservation</a></li>
                <li><a href="admin/login.php">Admin</a></li>
            </ul>
        </div>
    </nav>

    <!-- About Section -->
    <section class="about-section">
        <div class="container">
            <h2>About Café Delight</h2>
            <div class="about-content">
                <div class="about-text">
                    <p>Welcome to Café Delight, where every cup tells a story. Since 2015, we've been serving the community with premium coffee, freshly baked goods, and warm hospitality.</p>
                    <p>Our mission is to create a welcoming space where friends and families can gather, relax, and enjoy quality food and beverages made with care and passion.</p>
                </div>
                <div id="staffInfo" class="staff-section">
                    <h3>Meet Our Team</h3>
                    <div id="staffContainer">
                        <p class="loading">Loading staff information...</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Café Delight. All rights reserved.</p>
            <p style="margin-top: 1rem; opacity: 0.8; font-size: 0.9rem;">
                <a href="admin/login.php" style="color: #D4AF37; text-decoration: none;">Admin Login</a>
            </p>
        </div>
    </footer>

    <!-- JavaScript for loading JSON data -->
    <script src="js/about.js"></script>
</body>
</html>

