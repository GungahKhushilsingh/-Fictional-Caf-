<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Café Delight - Home</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Navigation Menu -->
    <nav class="navbar">
        <div class="container">
            <div class="logo">
                <h1>☕ Café Delight</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php" class="active">Home</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="reservation.php">Reservation</a></li>
                <li><a href="admin/login.php">Admin</a></li>
            </ul>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero" style="background: url('image/pic1.jpg') center/cover no-repeat;">
        <div class="hero-content">
            <h2>Welcome to Café Delight</h2>
            <p>An Experience Beyond Coffee</p>
            <a href="menu.php" class="btn btn-primary">View Menu</a>
            <a href="reservation.php" class="btn btn-primary" style="margin-left: 1rem;">Reserve Your Table</a>
        </div>
    </section>

    <!-- Our Story Section -->
    <section class="story-section">
        <div class="container">
            <div class="story-header">
                <h2>Our Story</h2>
                <p class="story-subtitle">A Journey of Passion & Community</p>
            </div>
            <div class="story-content">
                <div class="story-card">
                    <div class="story-text">
                        <p class="story-intro">
                            It all began with a simple dream – to create a place where coffee isn't just a beverage, but a bridge that connects people, stories, and moments. In 2015, Café Delight opened its doors in the heart of the city, born from our founder's love for authentic coffee culture and the belief that every cup should tell a story.
                        </p>
                        <p>
                            We started small, with a mission to source only the finest beans from ethical farms around the world. Each blend is carefully crafted, roasted to perfection, and served with warmth that goes beyond the perfect temperature. Our baristas aren't just coffee makers – they're storytellers, crafting each cup with dedication and passion.
                        </p>
                        <p>
                            Over the years, Café Delight has grown into more than just a café. It's become a gathering place for writers finding their muse, students studying for exams, friends catching up over lattes, and neighbors starting their day with that perfect espresso. Every corner holds a memory, every table has witnessed conversations that matter.
                        </p>
                        <p class="story-quote">
                            "Coffee is a language in itself, and we're here to help you speak it fluently."
                        </p>
                        <p>
                            Today, we continue our journey with the same values: quality ingredients, community connection, and the warm, welcoming atmosphere that makes everyone feel at home. Whether you're here for your morning ritual, a midday break, or an evening treat, we're honored to be part of your day.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Section Divider -->
    <div class="section-divider"></div>

    <!-- Special Offers Section (loaded via AJAX from JSON) -->
    <section class="offers">
        <div class="container">
            <div class="offers-header">
                <h2>Today's Special Offers</h2>
            </div>
            <div id="offersContainer">
                <p class="loading">Loading offers...</p>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div>
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="menu.php">Menu</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="reservation.php">Reservation</a></li>
                </ul>
            </div>
            <div>
                <h4>Contact Us</h4>
                <p>123 Main Street<br>Springfield, IL 62701</p>
                <p>Phone: +1 (555) 123-4567</p>
                <p>Email: info@cafedelight.com</p>
            </div>
            <div>
                <h4>Follow Us</h4>
                <div class="social-icons">
                    <a href="#" aria-label="Facebook">📘</a>
                    <a href="#" aria-label="Instagram">📷</a>
                    <a href="#" aria-label="Twitter">🐦</a>
                </div>
            </div>
            <div>
                <h4>Newsletter</h4>
                <p>Subscribe to get updates on special offers and events.</p>
                <form class="newsletter-form" onsubmit="subscribeNewsletter(event)">
                    <input type="email" name="email" placeholder="Your email address" required>
                    <button type="submit">Subscribe</button>
                </form>
                <div id="newsletterMessage" style="margin-top: 0.5rem; font-size: 0.9rem;"></div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 Café Delight. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript for AJAX and DOM manipulation -->
    <script src="js/main.js"></script>
</body>
</html>

