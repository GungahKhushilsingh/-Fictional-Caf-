<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserve a Table – Café Delight</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Reservation Page Specific Styles - Light Theme */
        .reservation-form .form-group label {
            color: #3E2C23;
            font-weight: 600;
        }
        
        .reservation-form .form-group input {
            background: #FAFAFA;
            border: 2px solid #E8DDD0;
            color: #1A1A1A;
            transition: all 0.3s ease;
        }
        
        .reservation-form .form-group input:focus {
            border-color: #D4AF37;
            background: #FFFFFF;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.15);
        }
        
        .reservation-form .form-group input::placeholder {
            color: #999;
        }
        
        .reservation-form h3,
        .reservation-form h2 {
            color: #3E2C23;
            margin-bottom: 1.5rem;
        }
        
        /* Message styles */
        .message {
            padding: 12px 16px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .message.info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
    </style>
</head>
<body>
    <!-- Navigation Menu -->
    <nav class="navbar">
        <div class="container">
            <div class="logo"><h1>☕ Café Delight</h1></div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="reservation.php" class="active">Reservation</a></li>
                <li><a href="admin/login.php">Admin</a></li>
            </ul>
        </div>
    </nav>

    <!-- Hero Banner for Reservation -->
    <section class="hero" style="padding: 6rem 0 4rem 0; min-height: 60vh; background-position: center center; background: url('image/reservation.jpg') center/cover no-repeat;">
        <div class="hero-content" style="max-width: 600px; margin: 0 auto;">
            <h2 style="font-size: 2.8rem; color: #FAFAFA;">Reserve Your Table</h2>
            <p style="color: #FAFAFA;">Book a table for a premium coffee experience. Our team is delighted to serve you!</p>
        </div>
    </section>

    <!-- Reservation Form -->
    <section style="padding: 3.5rem 0; background: linear-gradient(135deg, #F5EFE6 0%, #E8DDD0 100%);">
        <div class="container" style="max-width: 520px;">
            <form class="reservation-form" id="reservationForm" action="" method="post" style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 8px 32px rgba(62, 44, 35, 0.15); padding: 2.6rem 2rem; margin: 0 auto; border: 2px solid rgba(212,175,55,0.3);">
                <div id="res-feedback" class="message" style="display:none; padding: 12px 16px; border-radius: 6px; margin-bottom: 20px;"></div>
                <div class="form-group">
                    <label for="res-name">Full Name</label>
                    <input type="text" id="res-name" name="name" required placeholder="Your Name">
                </div>
                <div class="form-group">
                    <label for="res-email">Email</label>
                    <input type="email" id="res-email" name="email" required placeholder="mail@example.com">
                </div>
                <div class="form-group">
                    <label for="res-phone">Phone</label>
                    <input type="tel" id="res-phone" name="phone" required placeholder="123-456-7890">
                </div>
                <div class="form-group">
                    <label for="res-date">Date</label>
                    <input type="date" id="res-date" name="date" required>
                </div>
                <div class="form-group">
                    <label for="res-time">Time</label>
                    <input type="time" id="res-time" name="time" required step="900">
                </div>
                <div class="form-group">
                    <label for="res-guests">Guests</label>
                    <input type="number" min="1" max="16" id="res-guests" name="guests" required placeholder="2">
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%; margin-top:18px;">Reserve Table</button>
            </form>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Café Delight. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Embedded reservation form handler - using the proven working code from test form
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('.reservation-form');
            if (!form) {
                console.error('Reservation form not found!');
                return;
            }
            
            const feedback = document.getElementById('res-feedback');
            
            function showMessage(type, text) {
                if (!feedback) return;
                const typeClass = type === 'error' ? 'error' : (type === 'info' ? 'info' : 'success');
                feedback.className = 'message ' + typeClass;
                feedback.textContent = text;
                feedback.style.display = 'block';
                if (type !== 'info') {
                    setTimeout(function() {
                        feedback.style.display = 'none';
                    }, 5000);
                }
            }
            
            form.addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const resultDiv = feedback || document.getElementById('res-feedback');
                if (resultDiv) {
                    resultDiv.className = 'message info';
                    resultDiv.innerHTML = 'Submitting...';
                    resultDiv.style.display = 'block';
                }
                
                const formData = new FormData(this);
                
                try {
                    const response = await fetch('api/submit_reservation.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        if (resultDiv) {
                            resultDiv.className = 'message success';
                            resultDiv.innerHTML = '✓ Success! ' + data.message;
                            resultDiv.style.display = 'block';
                        }
                        form.reset();
                    } else {
                        if (resultDiv) {
                            resultDiv.className = 'message error';
                            resultDiv.innerHTML = '✗ Error: ' + (data.error || 'Unknown error');
                            resultDiv.style.display = 'block';
                        }
                    }
                } catch (error) {
                    console.error('Error:', error);
                    if (resultDiv) {
                        resultDiv.className = 'message error';
                        resultDiv.innerHTML = '✗ Network Error: ' + error.message;
                        resultDiv.style.display = 'block';
                    }
                }
            });
        });
    </script>
</body>
</html>
